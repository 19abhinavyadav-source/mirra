"""
blueprints/session.py — Tutoring session routes.

  POST /session/start          — create/resume a session
  POST /session/ask/stream     — stream Claude Socratic response (SSE)
  POST /session/transcribe     — voice → text via Whisper
  GET  /session/<id>/history   — full transcript
  POST /session/<id>/close     — mark session ended
"""

import base64
import logging
import os
import tempfile
from datetime import datetime, timezone
from functools import wraps

from flask import Blueprint, Response, jsonify, request, stream_with_context
from flask_login import current_user, login_required

from ai.ask_handler import handle_ask_stream
from extensions import db, redis_client
from models import Exchange, Session

logger = logging.getLogger(__name__)
session_bp = Blueprint("session", __name__)


# ── Decorators ────────────────────────────────────────────────────────────────

def subscription_active(f):
    """Block if user has no questions remaining."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.can_ask():
            return jsonify({
                "error": "QUESTION_LIMIT_EXCEEDED",
                "questions_remaining": 0,
                "reset_date": current_user.questions_reset_at.isoformat()
                if current_user.questions_reset_at else None,
                "plan": current_user.plan,
            }), 402
        return f(*args, **kwargs)
    return decorated


def rate_limit_ask(f):
    """Per-user per-minute rate limit: max 6 /ask calls per minute."""
    @wraps(f)
    def decorated(*args, **kwargs):
        key = f"rate:ask:{current_user.id}"
        count = redis_client.incr(key)
        if count == 1:
            redis_client.expire(key, 60)
        if count > 6:
            return jsonify({"error": "RATE_LIMIT", "message": "Slow down — Mirra needs a moment too."}), 429
        return f(*args, **kwargs)
    return decorated


# ── Routes ────────────────────────────────────────────────────────────────────

@session_bp.route("/start", methods=["POST"])
@login_required
def start_session():
    data = request.get_json(silent=True) or {}
    topic = (data.get("topic") or "").strip()[:500]
    if not topic:
        return jsonify({"error": "TOPIC_REQUIRED"}), 400

    # Check for active session on same topic (allow resuming)
    existing = (
        Session.query
        .filter_by(user_id=current_user.id)
        .filter(Session.topic == topic, Session.ended_at.is_(None))
        .first()
    )
    if existing:
        return jsonify({"session_id": existing.id, "resumed": True}), 200

    new_session = Session(
        user_id=current_user.id,
        topic=topic,
        assessment_context=current_user.active_assessment,
        subject=data.get("subject"),
    )
    db.session.add(new_session)
    db.session.commit()

    return jsonify({"session_id": new_session.id, "resumed": False}), 201


@session_bp.route("/ask/stream", methods=["POST"])
@login_required
@subscription_active
@rate_limit_ask
def ask_stream():
    """
    Main SSE streaming endpoint. Returns text/event-stream.

    Body (multipart or JSON):
      topic         — the IB topic being discussed
      text          — student's message (required unless voice/image only)
      session_id    — optional, to continue existing session
      voice         — optional base64 audio blob (transcribed first)
      image         — optional base64 image
    """
    # Parse request
    if request.content_type and "multipart" in request.content_type:
        topic = request.form.get("topic", "").strip()
        text = request.form.get("text", "").strip()
        session_id = request.form.get("session_id")
        input_type = request.form.get("input_type", "text")
        image_b64 = request.form.get("image")  # already base64
        voice_blob = request.files.get("voice")
    else:
        data = request.get_json(silent=True) or {}
        topic = data.get("topic", "").strip()
        text = data.get("text", "").strip()
        session_id = data.get("session_id")
        input_type = data.get("input_type", "text")
        image_b64 = data.get("image")
        voice_blob = None

    if not topic:
        return jsonify({"error": "TOPIC_REQUIRED"}), 400

    # Handle voice input
    if voice_blob or input_type in ("voice", "combined"):
        transcribed = _transcribe_voice(voice_blob)
        if transcribed:
            text = transcribed if not text else f"{text}\n\n[Voice note: {transcribed}]"
            input_type = "combined" if image_b64 else "voice"

    if not text and not image_b64:
        return jsonify({"error": "NO_INPUT"}), 400

    # Validate inputs
    text = text[:5000]
    topic = topic[:500]

    generator = handle_ask_stream(
        user=current_user,
        topic=topic,
        student_input=text or "[Image submitted — see above]",
        session_id=session_id,
        input_type=input_type,
        image_b64=image_b64,
    )

    return Response(
        stream_with_context(generator),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


@session_bp.route("/transcribe", methods=["POST"])
@login_required
def transcribe():
    """Transcribe audio blob via Whisper."""
    audio_file = request.files.get("audio")
    if not audio_file:
        data = request.get_json(silent=True) or {}
        audio_b64 = data.get("audio_b64")
        if not audio_b64:
            return jsonify({"error": "NO_AUDIO"}), 400
        audio_bytes = base64.b64decode(audio_b64)
    else:
        audio_bytes = audio_file.read()

    transcription = _transcribe_bytes(audio_bytes)
    if not transcription:
        return jsonify({"error": "TRANSCRIPTION_FAILED"}), 500

    return jsonify({"text": transcription}), 200


@session_bp.route("/<session_id>/history", methods=["GET"])
@login_required
def session_history(session_id: str):
    session = Session.query.filter_by(id=session_id, user_id=current_user.id).first_or_404()

    cursor = request.args.get("cursor")
    limit = min(int(request.args.get("limit", 20)), 50)

    query = Exchange.query.filter_by(session_id=session.id).order_by(Exchange.exchange_number)
    if cursor:
        query = query.filter(Exchange.exchange_number > int(cursor))

    exchanges = query.limit(limit + 1).all()
    has_more = len(exchanges) > limit
    exchanges = exchanges[:limit]

    return jsonify({
        "session": session.to_dict(),
        "exchanges": [
            {
                "exchange_number": e.exchange_number,
                "student_input": e.student_input,
                "mirra_response": e.mirra_response,
                "input_type": e.input_type,
                "question_type_used": e.question_type_used,
                "created_at": e.created_at.isoformat(),
            }
            for e in exchanges
        ],
        "cursor": exchanges[-1].exchange_number if exchanges else None,
        "has_more": has_more,
    }), 200


@session_bp.route("/<session_id>/close", methods=["POST"])
@login_required
def close_session(session_id: str):
    session = Session.query.filter_by(id=session_id, user_id=current_user.id).first_or_404()
    session.ended_at = datetime.now(timezone.utc)
    db.session.commit()

    # Clear conversation cache
    from ai.conversation import ConversationManager
    ConversationManager(session_id).clear()

    return jsonify({"success": True, "exchanges": session.exchange_count}), 200


# ── Helpers ───────────────────────────────────────────────────────────────────

def _transcribe_voice(audio_file) -> str:
    """Transcribe voice using OpenAI Whisper API."""
    if not audio_file:
        return ""
    try:
        audio_bytes = audio_file.read()
        return _transcribe_bytes(audio_bytes)
    except Exception as e:
        logger.error(f"Voice transcription failed: {e}")
        return ""


def _transcribe_bytes(audio_bytes: bytes) -> str:
    """Transcribe audio bytes. Falls back to empty string on failure."""
    try:
        import openai
        client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY", ""))
        with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
            f.write(audio_bytes)
            tmp_path = f.name
        with open(tmp_path, "rb") as f:
            transcript = client.audio.transcriptions.create(model="whisper-1", file=f)
        os.unlink(tmp_path)
        return transcript.text
    except Exception as e:
        logger.warning(f"Whisper transcription failed: {e}")
        return ""
