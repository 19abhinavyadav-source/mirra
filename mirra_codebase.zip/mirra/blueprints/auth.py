"""
blueprints/auth.py — Authentication: OTP via Twilio Verify, JWT tokens.

Endpoints:
  POST /auth/otp/send      — send OTP to phone number
  POST /auth/otp/verify    — verify OTP, return access + refresh tokens
  POST /auth/token/refresh — rotate refresh token
  POST /auth/logout        — blacklist refresh token
"""

import secrets
import logging
from datetime import datetime, timezone, timedelta

import jwt
from flask import Blueprint, request, jsonify, current_app
from flask_login import login_user, logout_user

from extensions import db, redis_client
from models import User, OtpAttempt

logger = logging.getLogger(__name__)
auth_bp = Blueprint("auth", __name__)


# ── Rate limit helpers ────────────────────────────────────────────────────────

def _get_or_create_otp_attempt(phone: str) -> OtpAttempt:
    now = datetime.now(timezone.utc)
    attempt = OtpAttempt.query.filter_by(phone_number=phone).first()
    if not attempt:
        attempt = OtpAttempt(phone_number=phone, window_start=now)
        db.session.add(attempt)
        db.session.commit()
        return attempt

    # Reset window if > 1 hour
    window_age = (now - attempt.window_start.replace(tzinfo=timezone.utc)).total_seconds()
    if window_age > 3600:
        attempt.sends_this_hour = 0
        attempt.fails_this_hour = 0
        attempt.window_start = now
        attempt.locked_until = None
        db.session.commit()

    return attempt


def _is_locked(attempt: OtpAttempt) -> bool:
    if not attempt.locked_until:
        return False
    now = datetime.now(timezone.utc)
    locked_until = attempt.locked_until.replace(tzinfo=timezone.utc)
    return now < locked_until


# ── JWT helpers ───────────────────────────────────────────────────────────────

def _make_access_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "type": "access",
        "iat": datetime.now(timezone.utc),
        "exp": datetime.now(timezone.utc) + current_app.config["JWT_ACCESS_TOKEN_EXPIRES"],
    }
    return jwt.encode(payload, current_app.config["SECRET_KEY"], algorithm="HS256")


def _make_refresh_token(user_id: str) -> str:
    token_id = secrets.token_hex(16)
    payload = {
        "sub": user_id,
        "jti": token_id,
        "type": "refresh",
        "iat": datetime.now(timezone.utc),
        "exp": datetime.now(timezone.utc) + current_app.config["JWT_REFRESH_TOKEN_EXPIRES"],
    }
    token = jwt.encode(payload, current_app.config["SECRET_KEY"], algorithm="HS256")
    # Track in Redis (for blacklisting on logout/rotation)
    ttl = int(current_app.config["JWT_REFRESH_TOKEN_EXPIRES"].total_seconds())
    redis_client.setex(f"refresh_token:{token_id}", ttl, user_id)
    return token


def _verify_token(token: str, expected_type: str) -> dict:
    try:
        payload = jwt.decode(token, current_app.config["SECRET_KEY"], algorithms=["HS256"])
        if payload.get("type") != expected_type:
            raise jwt.InvalidTokenError("Wrong token type")
        if expected_type == "refresh":
            jti = payload.get("jti")
            if not redis_client.exists(f"refresh_token:{jti}"):
                raise jwt.InvalidTokenError("Token revoked")
        return payload
    except jwt.ExpiredSignatureError:
        raise ValueError("TOKEN_EXPIRED")
    except jwt.InvalidTokenError as e:
        raise ValueError(f"TOKEN_INVALID: {e}")


# ── Routes ────────────────────────────────────────────────────────────────────

@auth_bp.route("/otp/send", methods=["POST"])
def otp_send():
    data = request.get_json(silent=True) or {}
    phone = data.get("phone_number", "").strip()

    # Validate phone
    import re
    if not re.match(r"^\+91[6-9]\d{9}$", phone):
        return jsonify({"error": "INVALID_PHONE", "message": "Enter a valid Indian mobile number"}), 400

    attempt = _get_or_create_otp_attempt(phone)

    if _is_locked(attempt):
        return jsonify({"error": "ACCOUNT_LOCKED", "message": "Too many failed attempts. Try again in 1 hour."}), 429

    max_sends = current_app.config.get("OTP_MAX_SENDS_PER_HOUR", 3)
    if attempt.sends_this_hour >= max_sends:
        return jsonify({"error": "RATE_LIMIT_EXCEEDED", "message": "Too many OTP requests. Try in 1 hour."}), 429

    # Send OTP via Twilio Verify
    try:
        if current_app.config.get("OTP_TEST_MODE"):
            # Test mode: store "000000" in Redis
            redis_client.setex(f"otp:{phone}", current_app.config.get("OTP_EXPIRY_SECONDS", 600), "000000")
        else:
            from twilio.rest import Client as TwilioClient
            twilio = TwilioClient(
                current_app.config["TWILIO_ACCOUNT_SID"],
                current_app.config["TWILIO_AUTH_TOKEN"],
            )
            twilio.verify.v2.services(current_app.config["TWILIO_VERIFY_SID"]).verifications.create(
                to=phone, channel="sms"
            )

        attempt.sends_this_hour += 1
        db.session.commit()
        logger.info(f"OTP sent to {phone}")
        return jsonify({"success": True, "message": "OTP sent"}), 200

    except Exception as e:
        logger.error(f"OTP send failed for {phone}: {e}")
        return jsonify({"error": "OTP_SEND_FAILED", "message": "Could not send OTP. Please try again."}), 500


@auth_bp.route("/otp/verify", methods=["POST"])
def otp_verify():
    data = request.get_json(silent=True) or {}
    phone = data.get("phone_number", "").strip()
    code = data.get("code", "").strip()

    if not phone or not code or len(code) != 6:
        return jsonify({"error": "INVALID_INPUT"}), 400

    attempt = _get_or_create_otp_attempt(phone)

    if _is_locked(attempt):
        return jsonify({"error": "ACCOUNT_LOCKED"}), 429

    # Verify
    verified = False
    if current_app.config.get("OTP_TEST_MODE"):
        stored = redis_client.get(f"otp:{phone}")
        verified = (stored == code or code == "000000")
    else:
        try:
            from twilio.rest import Client as TwilioClient
            twilio = TwilioClient(
                current_app.config["TWILIO_ACCOUNT_SID"],
                current_app.config["TWILIO_AUTH_TOKEN"],
            )
            result = twilio.verify.v2.services(current_app.config["TWILIO_VERIFY_SID"]).verification_checks.create(
                to=phone, code=code
            )
            verified = (result.status == "approved")
        except Exception as e:
            logger.error(f"OTP verify failed: {e}")
            return jsonify({"error": "VERIFY_ERROR"}), 500

    if not verified:
        attempt.fails_this_hour += 1
        max_fails = current_app.config.get("OTP_MAX_FAILS_BEFORE_LOCKOUT", 5)
        if attempt.fails_this_hour >= max_fails:
            attempt.locked_until = datetime.now(timezone.utc) + timedelta(hours=1)
            logger.warning(f"Account locked for {phone} after {max_fails} fails")
        db.session.commit()
        return jsonify({"error": "INVALID_OTP", "message": "Incorrect code"}), 400

    # OTP valid — get or create user
    user = User.query.filter_by(phone_number=phone).first()
    if not user:
        from datetime import datetime as dt
        user = User(
            phone_number=phone,
            plan="trial",
            trial_started_at=dt.now(timezone.utc),
            question_limit=20,
        )
        db.session.add(user)

    user.last_active_at = datetime.now(timezone.utc)
    attempt.fails_this_hour = 0  # reset on success
    db.session.commit()

    login_user(user)

    access_token = _make_access_token(user.id)
    refresh_token = _make_refresh_token(user.id)

    return jsonify({
        "access_token": access_token,
        "refresh_token": refresh_token,
        "user_id": user.id,
        "is_onboarded": user.is_onboarded,
        "plan": user.plan,
    }), 200


@auth_bp.route("/token/refresh", methods=["POST"])
def token_refresh():
    data = request.get_json(silent=True) or {}
    refresh_token = data.get("refresh_token")
    if not refresh_token:
        return jsonify({"error": "NO_TOKEN"}), 401

    try:
        payload = _verify_token(refresh_token, "refresh")
    except ValueError as e:
        return jsonify({"error": str(e)}), 401

    user_id = payload["sub"]
    jti = payload["jti"]

    # Blacklist old token (rotation)
    redis_client.delete(f"refresh_token:{jti}")

    user = User.query.get(user_id)
    if not user or not user.is_active:
        return jsonify({"error": "USER_NOT_FOUND"}), 401

    new_access = _make_access_token(user_id)
    new_refresh = _make_refresh_token(user_id)

    return jsonify({
        "access_token": new_access,
        "refresh_token": new_refresh,
    }), 200


@auth_bp.route("/logout", methods=["POST"])
def logout():
    data = request.get_json(silent=True) or {}
    refresh_token = data.get("refresh_token")
    if refresh_token:
        try:
            payload = _verify_token(refresh_token, "refresh")
            redis_client.delete(f"refresh_token:{payload['jti']}")
        except Exception:
            pass
    logout_user()
    return jsonify({"success": True}), 200
