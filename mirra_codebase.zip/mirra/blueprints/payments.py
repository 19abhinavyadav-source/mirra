"""
blueprints/payments.py — Razorpay payment integration.

  POST /payments/create-order   — create Razorpay order
  POST /payments/verify         — verify signature, activate subscription
  POST /payments/webhook        — idempotent webhook handler
  GET  /payments/plans          — list available plans
"""

import hashlib
import hmac
import logging
from datetime import datetime, timezone, timedelta

from flask import Blueprint, jsonify, request, current_app
from flask_login import current_user, login_required

from extensions import db
from models import Payment, Subscription, User

logger = logging.getLogger(__name__)
payments_bp = Blueprint("payments", __name__)

PLAN_NAMES = {
    "basic": "Mirra Basic",
    "pro": "Mirra Pro",
    "elite": "Mirra Elite",
}


# ── Routes ────────────────────────────────────────────────────────────────────

@payments_bp.route("/plans", methods=["GET"])
def list_plans():
    """Public endpoint — no auth required."""
    prices = current_app.config["PLAN_PRICES_PAISE"]
    limits = current_app.config["PLAN_LIMITS"]
    return jsonify({
        "plans": [
            {
                "id": "basic",
                "name": "Basic",
                "price_paise": prices["basic"],
                "price_inr": prices["basic"] // 100,
                "questions": limits["basic"],
                "recommended": False,
            },
            {
                "id": "pro",
                "name": "Pro",
                "price_paise": prices["pro"],
                "price_inr": prices["pro"] // 100,
                "questions": limits["pro"],
                "recommended": True,
            },
            {
                "id": "elite",
                "name": "Elite",
                "price_paise": prices["elite"],
                "price_inr": prices["elite"] // 100,
                "questions": limits["elite"],
                "recommended": False,
            },
        ]
    }), 200


@payments_bp.route("/create-order", methods=["POST"])
@login_required
def create_order():
    data = request.get_json(silent=True) or {}
    plan = data.get("plan")

    valid_plans = current_app.config["PLAN_PRICES_PAISE"].keys()
    if plan not in valid_plans:
        return jsonify({"error": "INVALID_PLAN"}), 400

    amount_paise = current_app.config["PLAN_PRICES_PAISE"][plan]

    try:
        import razorpay
        rz = razorpay.Client(
            auth=(current_app.config["RAZORPAY_KEY_ID"], current_app.config["RAZORPAY_KEY_SECRET"])
        )
        order = rz.order.create({
            "amount": amount_paise,
            "currency": "INR",
            "receipt": f"mirra_{current_user.id[:8]}_{plan}",
            "notes": {"user_id": current_user.id, "plan": plan},
        })

        # Record pending payment
        payment = Payment(
            user_id=current_user.id,
            razorpay_order_id=order["id"],
            amount_paise=amount_paise,
            plan=plan,
            status="pending",
        )
        db.session.add(payment)
        db.session.commit()

        return jsonify({
            "order_id": order["id"],
            "amount": amount_paise,
            "currency": "INR",
            "key_id": current_app.config["RAZORPAY_KEY_ID"],
            "user_name": current_user.name or "",
        }), 201

    except Exception as e:
        logger.error(f"Create order failed: {e}")
        return jsonify({"error": "ORDER_CREATE_FAILED"}), 500


@payments_bp.route("/verify", methods=["POST"])
@login_required
def verify_payment():
    """
    Called by frontend after Razorpay.open() succeeds.
    Verifies HMAC signature, upgrades user plan.
    """
    data = request.get_json(silent=True) or {}
    order_id = data.get("razorpay_order_id")
    payment_id = data.get("razorpay_payment_id")
    signature = data.get("razorpay_signature")

    if not all([order_id, payment_id, signature]):
        return jsonify({"error": "MISSING_FIELDS"}), 400

    # Verify Razorpay HMAC-SHA256 signature
    expected_sig = hmac.new(
        current_app.config["RAZORPAY_KEY_SECRET"].encode(),
        f"{order_id}|{payment_id}".encode(),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected_sig, signature):
        logger.warning(f"Invalid Razorpay signature for order {order_id}")
        return jsonify({"error": "INVALID_SIGNATURE"}), 400

    # Find pending payment (idempotency: skip if already processed)
    payment = Payment.query.filter_by(
        razorpay_order_id=order_id,
        user_id=current_user.id,
    ).first()

    if not payment:
        return jsonify({"error": "ORDER_NOT_FOUND"}), 404

    if payment.status == "success":
        return jsonify({"success": True, "already_processed": True}), 200

    # Atomic: update payment + user plan in one transaction
    try:
        plan = payment.plan
        question_limit = current_app.config["PLAN_LIMITS"][plan]
        now = datetime.now(timezone.utc)

        payment.razorpay_payment_id = payment_id
        payment.razorpay_signature = signature
        payment.status = "success"
        payment.webhook_received_at = now

        current_user.plan = plan
        current_user.question_limit = question_limit
        current_user.monthly_questions_used = 0  # reset on new subscription
        current_user.paid_until = now + timedelta(days=30)
        current_user.questions_reset_at = now + timedelta(days=30)

        subscription = Subscription(
            user_id=current_user.id,
            plan=plan,
            status="active",
            started_at=now,
            expires_at=now + timedelta(days=30),
            question_limit=question_limit,
            price_paise=payment.amount_paise,
            razorpay_payment_id=payment_id,
        )
        db.session.add(subscription)
        db.session.commit()

        logger.info(f"Payment success: user={current_user.id} plan={plan}")
        return jsonify({
            "success": True,
            "plan": plan,
            "questions_remaining": question_limit,
        }), 200

    except Exception as e:
        db.session.rollback()
        logger.error(f"Payment activation failed: {e}")
        return jsonify({"error": "ACTIVATION_FAILED"}), 500


@payments_bp.route("/webhook", methods=["POST"])
def webhook():
    """
    Razorpay webhook handler (idempotent).
    Handles payment.captured and payment.failed events.
    """
    payload = request.get_data()
    sig = request.headers.get("X-Razorpay-Signature", "")

    # Verify webhook signature
    expected = hmac.new(
        current_app.config["RAZORPAY_KEY_SECRET"].encode(),
        payload,
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected, sig):
        logger.warning("Invalid webhook signature")
        return jsonify({"error": "INVALID_SIGNATURE"}), 400

    try:
        import json
        event = json.loads(payload)
        event_type = event.get("event")

        if event_type == "payment.captured":
            _handle_payment_captured(event)
        elif event_type == "payment.failed":
            _handle_payment_failed(event)

        return jsonify({"success": True}), 200
    except Exception as e:
        logger.error(f"Webhook processing failed: {e}")
        return jsonify({"error": "PROCESSING_FAILED"}), 500


def _handle_payment_captured(event: dict):
    """Idempotent handler for successful payment webhook."""
    payment_entity = event.get("payload", {}).get("payment", {}).get("entity", {})
    payment_id = payment_entity.get("id")
    order_id = payment_entity.get("order_id")

    if not payment_id or not order_id:
        return

    payment = Payment.query.filter_by(razorpay_order_id=order_id).first()
    if not payment or payment.status == "success":
        return  # Already processed (idempotency)

    try:
        plan = payment.plan
        question_limit = current_app.config["PLAN_LIMITS"][plan]
        now = datetime.now(timezone.utc)

        payment.razorpay_payment_id = payment_id
        payment.status = "success"
        payment.webhook_received_at = now

        user = User.query.get(payment.user_id)
        if user:
            user.plan = plan
            user.question_limit = question_limit
            user.paid_until = now + timedelta(days=30)

        db.session.commit()
        logger.info(f"Webhook: payment {payment_id} captured, user {payment.user_id} → {plan}")
    except Exception as e:
        db.session.rollback()
        logger.error(f"Webhook payment captured handler failed: {e}")


def _handle_payment_failed(event: dict):
    payment_entity = event.get("payload", {}).get("payment", {}).get("entity", {})
    order_id = payment_entity.get("order_id")
    if not order_id:
        return
    payment = Payment.query.filter_by(razorpay_order_id=order_id).first()
    if payment and payment.status == "pending":
        payment.status = "failed"
        db.session.commit()
