"""
blueprints/onboarding.py
blueprints/admin.py
blueprints/health.py
"""

# ══════════════════════════════════════════════════════════════════
# ONBOARDING
# ══════════════════════════════════════════════════════════════════
from flask import Blueprint, jsonify, request
from flask_login import current_user, login_required
from extensions import db

onboarding_bp = Blueprint("onboarding", __name__)

@onboarding_bp.route("/save", methods=["POST"])
@login_required
def save_onboarding():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()[:100]
    programme = data.get("programme")
    subjects = data.get("subjects", [])
    active_assessment = data.get("active_assessment")
    assessment_deadline = data.get("assessment_deadline")

    VALID_PROGRAMMES = ("IB_DP", "IB_MYP", "IGCSE", "A_LEVELS")
    VALID_ASSESSMENTS = ("TOK_ESSAY", "EXTENDED_ESSAY", "IA", "EXAM_PREP")

    if programme and programme not in VALID_PROGRAMMES:
        return jsonify({"error": "INVALID_PROGRAMME"}), 400
    if active_assessment and active_assessment not in VALID_ASSESSMENTS:
        return jsonify({"error": "INVALID_ASSESSMENT"}), 400

    if name:
        current_user.name = name
    if programme:
        current_user.programme = programme
    if subjects:
        current_user.subjects = [s.strip() for s in subjects[:10] if s.strip()]
    if active_assessment:
        current_user.active_assessment = active_assessment
    if assessment_deadline:
        from datetime import datetime
        try:
            current_user.assessment_deadline = datetime.fromisoformat(assessment_deadline)
        except ValueError:
            pass

    current_user.is_onboarded = bool(name and programme and subjects and active_assessment)
    db.session.commit()

    return jsonify({"success": True, "is_onboarded": current_user.is_onboarded}), 200


# ══════════════════════════════════════════════════════════════════
# ADMIN
# ══════════════════════════════════════════════════════════════════
import logging
from functools import wraps
from flask_login import current_user
from models import User, Session, Payment, AnalyticsEvent
from sqlalchemy import func, desc
from datetime import datetime, timezone, timedelta

logger = logging.getLogger(__name__)
admin_bp = Blueprint("admin", __name__)

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            return jsonify({"error": "FORBIDDEN"}), 403
        return f(*args, **kwargs)
    return decorated

@admin_bp.route("/users", methods=["GET"])
@login_required
@admin_required
def list_users():
    page = int(request.args.get("page", 1))
    per_page = min(int(request.args.get("per_page", 50)), 100)
    users = User.query.order_by(User.created_at.desc()).paginate(page=page, per_page=per_page)
    return jsonify({
        "users": [
            {
                "id": u.id,
                "phone": u.phone_number,
                "name": u.name,
                "plan": u.plan,
                "session_count": u.session_count,
                "questions_remaining": u.questions_remaining(),
                "created_at": u.created_at.isoformat(),
                "last_active_at": u.last_active_at.isoformat() if u.last_active_at else None,
            }
            for u in users.items
        ],
        "total": users.total,
        "pages": users.pages,
        "page": page,
    }), 200

@admin_bp.route("/metrics", methods=["GET"])
@login_required
@admin_required
def metrics():
    now = datetime.now(timezone.utc)
    week_ago = now - timedelta(days=7)

    total_users = User.query.count()
    active_week = User.query.filter(User.last_active_at >= week_ago).count()
    paid_users = User.query.filter(User.plan.in_(["basic", "pro", "elite"])).count()
    total_sessions = Session.query.count()
    revenue_paise = db.session.query(func.sum(Payment.amount_paise)).filter_by(status="success").scalar() or 0

    return jsonify({
        "users_total": total_users,
        "users_active_7d": active_week,
        "users_paid": paid_users,
        "sessions_total": total_sessions,
        "revenue_inr": revenue_paise // 100,
    }), 200


# ══════════════════════════════════════════════════════════════════
# HEALTH
# ══════════════════════════════════════════════════════════════════
from extensions import redis_client as _redis

health_bp = Blueprint("health", __name__)

@health_bp.route("/health", methods=["GET"])
def health():
    checks = {}
    status = 200

    # DB check
    try:
        db.session.execute(db.text("SELECT 1"))
        checks["db"] = "ok"
    except Exception as e:
        checks["db"] = f"error: {e}"
        status = 503

    # Redis check
    try:
        _redis.ping()
        checks["redis"] = "ok"
    except Exception as e:
        checks["redis"] = f"error: {e}"
        status = 503

    return jsonify({
        "status": "ok" if status == 200 else "degraded",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }), status
