"""
blueprints/dashboard.py — User dashboard API.
"""
from flask import Blueprint, jsonify, request
from flask_login import current_user, login_required
from sqlalchemy import func
from models import Session, IbGap, WeeklyReport, Exchange
from extensions import db

dashboard_bp = Blueprint("dashboard", __name__)

@dashboard_bp.route("/stats", methods=["GET"])
@login_required
def stats():
    session_count = Session.query.filter_by(user_id=current_user.id).count()
    breakthroughs = Session.query.filter_by(user_id=current_user.id, breakthrough_achieved=True).count()

    return jsonify({
        "sessions_total": session_count,
        "breakthroughs": breakthroughs,
        "questions_remaining": current_user.questions_remaining(),
        "question_limit": current_user.question_limit,
        "streak_days": current_user.streak_days or 0,
        "plan": current_user.plan,
        "paid_until": current_user.paid_until.isoformat() if current_user.paid_until else None,
    }), 200

@dashboard_bp.route("/sessions", methods=["GET"])
@login_required
def sessions():
    cursor = request.args.get("cursor")
    limit = min(int(request.args.get("limit", 10)), 50)
    q = Session.query.filter_by(user_id=current_user.id).order_by(Session.started_at.desc())
    if cursor:
        from datetime import datetime
        q = q.filter(Session.started_at < datetime.fromisoformat(cursor))
    items = q.limit(limit + 1).all()
    has_more = len(items) > limit
    items = items[:limit]
    return jsonify({
        "sessions": [s.to_dict() for s in items],
        "cursor": items[-1].started_at.isoformat() if items else None,
        "has_more": has_more,
    }), 200

@dashboard_bp.route("/gaps", methods=["GET"])
@login_required
def gaps():
    items = (
        IbGap.query
        .filter_by(user_id=current_user.id, is_dismissed=False)
        .order_by(IbGap.occurrence_count.desc())
        .limit(10)
        .all()
    )
    return jsonify({"gaps": [g.to_dict() for g in items]}), 200

@dashboard_bp.route("/gaps/<gap_id>/dismiss", methods=["POST"])
@login_required
def dismiss_gap(gap_id):
    gap = IbGap.query.filter_by(id=gap_id, user_id=current_user.id).first_or_404()
    gap.is_dismissed = True
    db.session.commit()
    return jsonify({"success": True}), 200

@dashboard_bp.route("/weekly-report", methods=["GET"])
@login_required
def weekly_report():
    report = (
        WeeklyReport.query
        .filter_by(user_id=current_user.id)
        .order_by(WeeklyReport.generated_at.desc())
        .first()
    )
    if not report:
        return jsonify({"report": None}), 200
    from datetime import datetime, timezone
    report.read_at = datetime.now(timezone.utc)
    db.session.commit()
    return jsonify({
        "report": {
            "id": report.id,
            "week_start": report.week_start.isoformat() if report.week_start else None,
            "report_text": report.report_text,
            "sessions_count": report.sessions_count,
            "breakthroughs_count": report.breakthroughs_count,
            "generated_at": report.generated_at.isoformat() if report.generated_at else None,
        }
    }), 200
