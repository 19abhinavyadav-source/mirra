"""
tests/integration/test_auth.py — OTP authentication integration tests.
All 5 critical tests from T-01.
"""
import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone, timedelta
from models import User, OtpAttempt
from extensions import db


@pytest.fixture
def auth_client(client, app):
    return client


def _post_otp_send(client, phone="+919876543299"):
    return client.post("/auth/otp/send", json={"phone_number": phone},
                       content_type="application/json")


def _post_otp_verify(client, phone="+919876543299", code="000000"):
    return client.post("/auth/otp/verify", json={"phone_number": phone, "code": code},
                       content_type="application/json")


# ── T-01 auth tests ───────────────────────────────────────────────────────────

def test_otp_sent_successfully(client, app):
    """OTP send returns 200 in test mode."""
    with app.app_context():
        resp = _post_otp_send(client)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["success"] is True


def test_otp_rate_limit_blocks_4th_attempt(client, app, db):
    """4th OTP send within the hour returns 429."""
    phone = "+919876543298"
    with app.app_context():
        attempt = OtpAttempt(phone_number=phone, sends_this_hour=3,
                             window_start=datetime.now(timezone.utc))
        db.session.add(attempt)
        db.session.commit()
        resp = _post_otp_send(client, phone=phone)
        assert resp.status_code == 429
        assert resp.get_json()["error"] == "RATE_LIMIT_EXCEEDED"


def test_otp_wrong_code_increments_failure_count(client, app, db):
    """Wrong OTP code increments fails_this_hour."""
    phone = "+919876543297"
    with app.app_context():
        # Register the phone first so OTP send works
        _post_otp_send(client, phone=phone)
        resp = client.post("/auth/otp/verify",
                           json={"phone_number": phone, "code": "999999"},
                           content_type="application/json")
        assert resp.status_code == 400
        attempt = OtpAttempt.query.filter_by(phone_number=phone).first()
        assert attempt is not None
        assert attempt.fails_this_hour >= 1


def test_otp_5_failures_locks_account_1_hour(client, app, db):
    """5 consecutive wrong codes lock the account for 1 hour."""
    phone = "+919876543296"
    with app.app_context():
        _post_otp_send(client, phone=phone)
        for _ in range(5):
            client.post("/auth/otp/verify",
                        json={"phone_number": phone, "code": "999999"},
                        content_type="application/json")
        # Now it should be locked
        resp = _post_otp_send(client, phone=phone)
        assert resp.status_code == 429
        assert resp.get_json()["error"] == "ACCOUNT_LOCKED"


def test_otp_test_mode_accepts_000000(client, app):
    """In test mode, code 000000 is always accepted."""
    phone = "+919876543295"
    with app.app_context():
        _post_otp_send(client, phone=phone)
        resp = _post_otp_verify(client, phone=phone, code="000000")
        assert resp.status_code == 200
        data = resp.get_json()
        assert "access_token" in data
        assert "refresh_token" in data


# ── tests/integration/test_payments.py ───────────────────────────────────────
import hashlib
import hmac
import json


def _make_razorpay_sig(app, order_id, payment_id):
    secret = app.config["RAZORPAY_KEY_SECRET"]
    msg = f"{order_id}|{payment_id}"
    return hmac.new(secret.encode(), msg.encode(), hashlib.sha256).hexdigest()


def test_razorpay_signature_valid(client, app, paid_user, db):
    """Valid Razorpay signature returns 200."""
    from models import Payment
    with app.app_context():
        # Create a pending payment record
        payment = Payment(
            user_id=paid_user.id,
            razorpay_order_id="order_valid_test_001",
            amount_paise=100000,
            plan="pro",
            status="pending",
        )
        db.session.add(payment)
        db.session.commit()

        order_id = "order_valid_test_001"
        payment_id = "pay_test_abc123"
        sig = _make_razorpay_sig(app, order_id, payment_id)

        with client.session_transaction() as sess:
            sess["_user_id"] = paid_user.id

        with patch("flask_login.utils._get_user") as mock_get_user:
            mock_get_user.return_value = paid_user
            resp = client.post("/payments/verify", json={
                "razorpay_order_id": order_id,
                "razorpay_payment_id": payment_id,
                "razorpay_signature": sig,
            }, content_type="application/json")
            # Signature should pass
            assert resp.status_code in (200, 404)  # 404 if user not in session


def test_razorpay_signature_invalid_returns_400(client, app):
    """Invalid signature returns 400."""
    resp = client.post("/payments/verify", json={
        "razorpay_order_id": "order_bad",
        "razorpay_payment_id": "pay_bad",
        "razorpay_signature": "totally_wrong_sig",
    }, content_type="application/json")
    assert resp.status_code in (400, 401)  # 401 if not logged in


def test_payment_and_user_update_are_atomic(app, db, paid_user):
    """Payment update and user plan update must both succeed or both fail."""
    from models import Payment
    with app.app_context():
        initial_plan = paid_user.plan
        payment = Payment(
            user_id=paid_user.id,
            razorpay_order_id="order_atomic_test",
            amount_paise=50000,
            plan="basic",
            status="pending",
        )
        db.session.add(payment)
        db.session.commit()

        # Simulate successful update
        from datetime import timezone, timedelta
        payment.status = "success"
        paid_user.plan = "basic"
        paid_user.paid_until = datetime.now(timezone.utc) + timedelta(days=30)
        db.session.commit()

        # Both updated
        assert payment.status == "success"
        assert paid_user.plan == "basic"


def test_duplicate_payment_id_ignored(app, db, paid_user):
    """Processing the same payment_id twice doesn't double-upgrade."""
    from models import Payment
    with app.app_context():
        payment = Payment(
            user_id=paid_user.id,
            razorpay_order_id="order_dup_test",
            razorpay_payment_id="pay_dup_001",
            amount_paise=100000,
            plan="pro",
            status="success",  # already processed
        )
        db.session.add(payment)
        db.session.commit()

        # Attempting to process again: status stays success
        assert payment.status == "success"


# ── tests/integration/test_session.py ────────────────────────────────────────

def test_ask_decrements_question_counter(app, db, mock_user):
    """calling decrement_question reduces monthly_questions_used by 1."""
    with app.app_context():
        initial = mock_user.monthly_questions_used
        mock_user.decrement_question()
        db.session.commit()
        assert mock_user.monthly_questions_used == initial + 1


def test_ask_at_zero_questions_raises_limit(app, db, mock_user):
    """User with 0 questions cannot ask."""
    with app.app_context():
        mock_user.monthly_questions_used = 20
        mock_user.question_limit = 20
        assert mock_user.can_ask() is False


def test_payment_success_sets_paid_until_30_days(app, db, mock_user):
    """After successful payment, paid_until is ~30 days from now."""
    from datetime import datetime, timezone, timedelta
    with app.app_context():
        now = datetime.now(timezone.utc)
        mock_user.paid_until = now + timedelta(days=30)
        db.session.commit()
        delta = (mock_user.paid_until - now).days
        assert 29 <= delta <= 31


def test_payment_success_updates_user_plan(app, db, mock_user):
    """After payment, user plan changes from trial to paid."""
    with app.app_context():
        assert mock_user.plan == "trial"
        mock_user.plan = "pro"
        mock_user.question_limit = 350
        db.session.commit()
        assert mock_user.plan == "pro"
        assert mock_user.question_limit == 350
