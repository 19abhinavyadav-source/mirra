"""
tests/conftest.py — Shared fixtures for all test modules.
"""
import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime, timezone, timedelta

from app import create_app
from extensions import db as _db
from models import User, Session, Exchange, IbGap, Payment


@pytest.fixture(scope="session")
def app():
    app = create_app("testing")
    with app.app_context():
        _db.create_all()
        yield app
        _db.drop_all()


@pytest.fixture(scope="function")
def db(app):
    with app.app_context():
        yield _db
        _db.session.rollback()
        for table in reversed(_db.metadata.sorted_tables):
            _db.session.execute(table.delete())
        _db.session.commit()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def mock_user(db):
    user = User(
        phone_number="+919876543210",
        name="Test Student",
        programme="IB_DP",
        subjects=["TOK", "Biology HL"],
        active_assessment="TOK_ESSAY",
        plan="trial",
        trial_started_at=datetime.now(timezone.utc),
        question_limit=20,
        monthly_questions_used=0,
        is_onboarded=True,
        session_count=3,
    )
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def paid_user(db):
    user = User(
        phone_number="+919876543211",
        name="Paid Student",
        programme="IB_DP",
        subjects=["Economics HL"],
        active_assessment="EXTENDED_ESSAY",
        plan="pro",
        trial_started_at=datetime.now(timezone.utc) - timedelta(days=10),
        question_limit=350,
        monthly_questions_used=50,
        paid_until=datetime.now(timezone.utc) + timedelta(days=20),
        is_onboarded=True,
        session_count=15,
    )
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def mock_session(db, mock_user):
    session = Session(
        user_id=mock_user.id,
        topic="Newton's Third Law",
        assessment_context="EXAM_PREP",
        subject="Physics",
    )
    db.session.add(session)
    db.session.commit()
    return session
