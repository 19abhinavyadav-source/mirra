"""
tests/ai_eval/eval_framework.py — AI Prompt Quality Evaluation (T-02)

Run with: python -m tests.ai_eval.eval_framework
"""

import json
import os
import statistics
import logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)


# ── Eval Dataset — 20 test cases ─────────────────────────────────────────────

EVAL_DATASET = [
    # ── BLANK inputs (5 cases) ────────────────────────────────────────────────
    {
        "id": "blank_01",
        "input": "idk",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "TOK_ESSAY", "session_count": 3},
        "expected_behaviours": [
            "offers a concrete scenario or real-world anchor",
            "asks exactly one question",
            "does NOT say 'can you give me more' or 'tell me more'",
        ],
        "forbidden_behaviours": [
            "asks student to elaborate without giving context",
            "gives multiple questions",
            "explains the topic",
        ],
    },
    {
        "id": "blank_02",
        "input": "I don't know anything about this",
        "history": [],
        "student_profile": {"programme": "IGCSE", "assessment": "EXAM_PREP", "session_count": 1},
        "expected_behaviours": ["provides a grounding observation or example", "asks one question"],
        "forbidden_behaviours": ["asks for more without scaffolding", "gives lecture"],
    },
    {
        "id": "blank_03",
        "input": "",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "EXTENDED_ESSAY", "session_count": 8},
        "expected_behaviours": ["handles blank input gracefully", "asks one specific question"],
        "forbidden_behaviours": ["crashes", "produces error message", "multiple questions"],
    },
    {
        "id": "blank_04",
        "input": "nothing",
        "history": [{"role": "user", "content": "nothing"}, {"role": "assistant", "content": "What if you imagine a scientist who disagrees with gravity — what would they need to explain?"}],
        "student_profile": {"programme": "IB_DP", "assessment": "IA", "session_count": 5},
        "expected_behaviours": ["offers to skip to different topic", "does NOT repeat same type of question"],
        "forbidden_behaviours": ["repeats 'give me more' pattern", "gives explanation"],
    },
    {
        "id": "blank_05",
        "input": "no idea lol",
        "history": [],
        "student_profile": {"programme": "A_LEVELS", "assessment": "EXAM_PREP", "session_count": 0},
        "expected_behaviours": ["gives vivid scenario", "warm tone", "exactly one question"],
        "forbidden_behaviours": ["condescending", "multiple questions", "explains"],
    },

    # ── NEAR EMPTY inputs (3 cases) ───────────────────────────────────────────
    {
        "id": "near_empty_01",
        "input": "photosynthesis",
        "history": [],
        "student_profile": {"programme": "IGCSE", "assessment": "EXAM_PREP", "session_count": 2},
        "expected_behaviours": ["gives ONE grounding sentence", "asks them to reason from it"],
        "forbidden_behaviours": ["explains all of photosynthesis", "multiple questions"],
    },
    {
        "id": "near_empty_02",
        "input": "E = mc2",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "EXTENDED_ESSAY", "session_count": 10},
        "expected_behaviours": ["asks about meaning or implication", "one question only"],
        "forbidden_behaviours": ["explains the formula", "writes their essay for them"],
    },
    {
        "id": "near_empty_03",
        "input": "colonialism was bad",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "TOK_ESSAY", "session_count": 6},
        "expected_behaviours": ["probes what 'bad' means", "asks for definition or evidence"],
        "forbidden_behaviours": ["validates claim", "writes argument for them"],
    },

    # ── FRUSTRATION signals (3 cases) ─────────────────────────────────────────
    {
        "id": "frustration_01",
        "input": "just tell me the answer already",
        "history": [
            {"role": "user", "content": "War causes poverty"},
            {"role": "assistant", "content": "What would you say to someone who argues poverty caused the war instead?"},
            {"role": "user", "content": "I don't know, maybe"},
            {"role": "assistant", "content": "What evidence could support either direction?"},
        ],
        "student_profile": {"programme": "IGCSE", "assessment": "EXAM_PREP", "session_count": 2},
        "expected_behaviours": [
            "STOPS Socratic questioning",
            "consolidates what was figured out",
            "closes warmly",
        ],
        "forbidden_behaviours": ["ignores frustration signal", "keeps asking questions", "gives lecture"],
    },
    {
        "id": "frustration_02",
        "input": "I'm bored of this",
        "history": [
            {"role": "user", "content": "Democracy is the best system"},
            {"role": "assistant", "content": "What are you assuming about 'best' here?"},
        ],
        "student_profile": {"programme": "IB_DP", "assessment": "TOK_ESSAY", "session_count": 4},
        "expected_behaviours": ["acknowledges", "summarises progress", "offers to move on"],
        "forbidden_behaviours": ["dismisses boredom", "continues questioning"],
    },
    {
        "id": "frustration_03",
        "input": "stop going in circles",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "EXTENDED_ESSAY", "session_count": 12},
        "expected_behaviours": ["changes angle", "switches question type", "empathetic tone"],
        "forbidden_behaviours": ["rephrases same question", "defensive"],
    },

    # ── Essay writing requests (3 cases) ──────────────────────────────────────
    {
        "id": "essay_01",
        "input": "Can you write my TOK essay introduction for me?",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "TOK_ESSAY", "session_count": 7},
        "expected_behaviours": ["declines to write", "redirects to thinking", "asks one question about their claim"],
        "forbidden_behaviours": ["writes introduction", "writes any paragraph"],
    },
    {
        "id": "essay_02",
        "input": "Give me an example argument I can use in my EE",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "EXTENDED_ESSAY", "session_count": 5},
        "expected_behaviours": ["does NOT give ready-to-use argument", "helps them build one through questioning"],
        "forbidden_behaviours": ["provides pre-formed argument", "writes essay content"],
    },
    {
        "id": "essay_03",
        "input": "Is this a good thesis: 'Technology has made us less human'?",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "TOK_ESSAY", "session_count": 9},
        "expected_behaviours": ["does NOT evaluate if thesis is good or bad", "asks probing question"],
        "forbidden_behaviours": ["says 'that's a good thesis'", "validates or invalidates the claim"],
    },

    # ── Argument validation requests (3 cases) ────────────────────────────────
    {
        "id": "validation_01",
        "input": "I think my argument is solid — can you confirm?",
        "history": [{"role": "user", "content": "Climate change is caused by capitalism"}],
        "student_profile": {"programme": "IB_DP", "assessment": "EXTENDED_ESSAY", "session_count": 11},
        "expected_behaviours": ["does NOT validate", "asks probing question about argument"],
        "forbidden_behaviours": ["says argument is solid", "agrees or disagrees with claim"],
    },
    {
        "id": "validation_02",
        "input": "Was my example good?",
        "history": [],
        "student_profile": {"programme": "IGCSE", "assessment": "EXAM_PREP", "session_count": 3},
        "expected_behaviours": ["redirects rather than evaluates", "asks what makes a good example"],
        "forbidden_behaviours": ["says 'yes that's a good example'", "grades their work"],
    },
    {
        "id": "validation_03",
        "input": "Am I right that correlation doesn't imply causation?",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "IA", "session_count": 15},
        "expected_behaviours": ["doesn't simply confirm", "asks for application", "one question"],
        "forbidden_behaviours": ["simply says 'yes, correct'", "gives lecture on correlation"],
    },

    # ── Breakthrough moments (3 cases) ────────────────────────────────────────
    {
        "id": "breakthrough_01",
        "input": "Oh wait — so my whole argument assumed Western values are universal. That's the flaw!",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "TOK_ESSAY", "session_count": 8},
        "expected_behaviours": [
            "acknowledges the insight warmly (not sycophantically)",
            "helps them deepen it",
            "one question to extend the breakthrough",
        ],
        "forbidden_behaviours": ["ignores breakthrough", "immediately pivots to new topic", "over-effusive praise"],
    },
    {
        "id": "breakthrough_02",
        "input": "I think I understand now — the data doesn't prove the hypothesis, it just supports it",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "IA", "session_count": 5},
        "expected_behaviours": ["builds on the insight", "asks one extending question"],
        "forbidden_behaviours": ["says 'exactly!' repeatedly", "explains what they just realised"],
    },
    {
        "id": "breakthrough_03",
        "input": "So actually both sides of my argument might be true at different scales?",
        "history": [],
        "student_profile": {"programme": "IB_DP", "assessment": "EXTENDED_ESSAY", "session_count": 20},
        "expected_behaviours": ["affirms the intellectual complexity", "deepens with one question"],
        "forbidden_behaviours": ["dismisses nuance", "simplifies their insight"],
    },
]


# ── Scoring Rubric ────────────────────────────────────────────────────────────

SCORING_RUBRIC = """
Score this AI tutoring response on the following rubric. Output ONLY JSON.

RUBRIC:
1. socratic_adherence (0-3): 
   3 = exactly one question, no answers/explanations given
   2 = one question but slight explanation slipped in
   1 = multiple questions OR gave a small answer
   0 = explained, validated, or wrote content for student

2. question_quality (0-2):
   2 = targets an unexamined assumption or pushes genuine thinking
   1 = okay question but surface-level
   0 = no meaningful question or a leading question

3. tone_appropriateness (0-2):
   2 = warm but not sycophantic, direct without being harsh
   1 = slight issues (too formal, too casual, or slightly preachy)
   0 = cold, dismissive, or over-praising

4. context_sensitivity (0-2):
   2 = correctly matched to IGCSE/TOK/EE/IA context
   1 = somewhat appropriate
   0 = wrong context (e.g., deep TOK question for IGCSE exam prep)

5. signal_handling (0-1):
   1 = correctly handled boredom/frustration/blank/breakthrough signal
   0 = ignored the signal

Total: 0–10

Response to score: {mirra_response}
Student context: {student_context}
Expected behaviours: {expected_behaviours}
Forbidden behaviours: {forbidden_behaviours}

Output JSON only: {{"socratic_adherence": N, "question_quality": N, "tone_appropriateness": N, "context_sensitivity": N, "signal_handling": N, "total": N, "reasoning": "one sentence"}}
"""


# ── Evaluator ─────────────────────────────────────────────────────────────────

class MirraEvaluator:
    def __init__(self, anthropic_api_key: str):
        import anthropic
        self.client = anthropic.Anthropic(api_key=anthropic_api_key)

    def get_mirra_response(self, test_case: dict, system_prompt: str) -> str:
        """Get Mirra's response for a test case."""
        messages = test_case.get("history", []) + [
            {"role": "user", "content": test_case["input"] or "[blank input]"}
        ]
        response = self.client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=300,
            system=system_prompt,
            messages=messages,
        )
        return response.content[0].text

    def score_response(self, response: str, test_case: dict) -> dict:
        """Score a response using Haiku as judge."""
        prompt = SCORING_RUBRIC.format(
            mirra_response=response[:2000],
            student_context=json.dumps(test_case["student_profile"]),
            expected_behaviours=json.dumps(test_case["expected_behaviours"]),
            forbidden_behaviours=json.dumps(test_case["forbidden_behaviours"]),
        )
        result = self.client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = result.content[0].text.strip()
        clean = raw.strip("```json").strip("```").strip()
        return json.loads(clean)

    def run_eval(self, system_prompt_a: str, system_prompt_b: Optional[str] = None) -> dict:
        """
        Run evaluation against all 20 test cases.
        If system_prompt_b provided, compare A vs B and alert on regression.
        """
        results_a = []
        results_b = []

        for case in EVAL_DATASET:
            print(f"  Evaluating case: {case['id']}...")
            resp_a = self.get_mirra_response(case, system_prompt_a)
            score_a = self.score_response(resp_a, case)
            results_a.append({"case_id": case["id"], "response": resp_a, "scores": score_a})

            if system_prompt_b:
                resp_b = self.get_mirra_response(case, system_prompt_b)
                score_b = self.score_response(resp_b, case)
                results_b.append({"case_id": case["id"], "response": resp_b, "scores": score_b})

        mean_a = statistics.mean(r["scores"]["total"] for r in results_a)

        output = {
            "timestamp": datetime.utcnow().isoformat(),
            "mean_score_a": round(mean_a, 2),
            "results_a": results_a,
        }

        if system_prompt_b and results_b:
            mean_b = statistics.mean(r["scores"]["total"] for r in results_b)
            delta = mean_b - mean_a
            output["mean_score_b"] = round(mean_b, 2)
            output["delta"] = round(delta, 2)
            output["results_b"] = results_b

            if delta < -0.5:
                output["regression_detected"] = True
                logger.critical(f"PROMPT REGRESSION DETECTED: delta={delta:.2f}, mean_a={mean_a:.2f}, mean_b={mean_b:.2f}")
                raise RuntimeError(f"PROMPT REGRESSION: new prompt scored {mean_b:.2f} vs {mean_a:.2f} (delta={delta:.2f})")
            else:
                output["regression_detected"] = False

        return output


# ── CLI Runner ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("ERROR: ANTHROPIC_API_KEY not set")
        sys.exit(1)

    from ai.mirra_brain import IB_SYSTEM_PROMPT
    evaluator = MirraEvaluator(api_key)
    print(f"Running eval against {len(EVAL_DATASET)} test cases...")
    results = evaluator.run_eval(IB_SYSTEM_PROMPT)
    print(f"\nMean score: {results['mean_score_a']}/10")
    print(f"Results saved to eval_results_{datetime.utcnow().strftime('%Y%m%d_%H%M')}.json")
    with open(f"eval_results_{datetime.utcnow().strftime('%Y%m%d_%H%M')}.json", "w") as f:
        json.dump(results, f, indent=2)
