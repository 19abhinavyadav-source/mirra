"""
tests/unit/test_models.py — Unit tests for User model business logic.
All 5 critical tests from T-01.
"""
import pytest
from datetime import datetime, timezone, timedelta
from models import User


# ── test_user_can_ask_trial_active ────────────────────────────────────────────
def test_user_can_ask_trial_active(mock_user):
    """Trial user within 7 days with questions remaining can ask."""
    mock_user.plan = "trial"
    mock_user.monthly_questions_used = 5
    mock_user.question_limit = 20
    mock_user.trial_started_at = datetime.now(timezone.utc) - timedelta(days=2)
    assert mock_user.can_ask() is True


def test_user_can_ask_trial_expired_by_time(mock_user):
    """Trial user past 7-day window cannot ask."""
    mock_user.plan = "trial"
    mock_user.monthly_questions_used = 5
    mock_user.question_limit = 20
    mock_user.trial_started_at = datetime.now(timezone.utc) - timedelta(days=8)
    assert mock_user.can_ask() is False


def test_user_can_ask_trial_no_questions_remaining(mock_user):
    """Trial user with 0 questions remaining cannot ask."""
    mock_user.plan = "trial"
    mock_user.monthly_questions_used = 20
    mock_user.question_limit = 20
    mock_user.trial_started_at = datetime.now(timezone.utc) - timedelta(days=1)
    assert mock_user.can_ask() is False


def test_user_decrement_question_updates_counter(mock_user):
    """decrement_question() increments both monthly and trial counters."""
    initial_monthly = mock_user.monthly_questions_used
    initial_trial = mock_user.trial_questions_used
    mock_user.decrement_question()
    assert mock_user.monthly_questions_used == initial_monthly + 1
    assert mock_user.trial_questions_used == initial_trial + 1


def test_user_paid_active_with_future_paid_until(paid_user):
    """Paid user with future paid_until and questions remaining can ask."""
    paid_user.monthly_questions_used = 100
    paid_user.question_limit = 350
    paid_user.paid_until = datetime.now(timezone.utc) + timedelta(days=15)
    assert paid_user.can_ask() is True


def test_user_paid_expired_paid_until(paid_user):
    """Paid user past paid_until cannot ask."""
    paid_user.plan = "pro"
    paid_user.paid_until = datetime.now(timezone.utc) - timedelta(days=1)
    assert paid_user.can_ask() is False


def test_questions_remaining_correct(mock_user):
    mock_user.question_limit = 20
    mock_user.monthly_questions_used = 7
    assert mock_user.questions_remaining() == 13


def test_questions_remaining_never_negative(mock_user):
    mock_user.question_limit = 20
    mock_user.monthly_questions_used = 25  # over limit somehow
    assert mock_user.questions_remaining() == 0


def test_decrement_only_monthly_for_paid(paid_user):
    """Paid user decrement does not touch trial counter."""
    paid_user.plan = "pro"
    paid_user.trial_questions_used = 0
    initial_trial = paid_user.trial_questions_used
    paid_user.decrement_question()
    # trial_questions_used only incremented for trial plan
    # paid user plan is "pro", so trial counter should NOT increment
    assert paid_user.trial_questions_used == initial_trial
