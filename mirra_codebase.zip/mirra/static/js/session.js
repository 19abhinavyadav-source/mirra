/**
 * session.js — Mirra session page interaction engine (F-02)
 *
 * Implements:
 *   sendMessage()        — SSE streaming submit
 *   startRecording()     — MediaRecorder voice capture
 *   handleImageUpload()  — image preview + base64 encoding
 *   updateQuestionCounter() — green/amber/red thresholds
 *   handleLimitReached() — upgrade modal
 */

'use strict';

// ── State ────────────────────────────────────────────────────────────────────
const State = {
  sessionId:         null,
  topic:             null,
  isStreaming:       false,
  mediaRecorder:     null,
  audioChunks:       [],
  isRecording:       false,
  pendingImageB64:   null,
  questionsRemaining: 0,
  questionLimit:     20,
  recordingTimer:    null,
};

// ── DOM refs ─────────────────────────────────────────────────────────────────
const DOM = {
  conversation: () => document.getElementById('conversation-area'),
  textarea:     () => document.getElementById('message-input'),
  sendBtn:      () => document.getElementById('send-btn'),
  micBtn:       () => document.getElementById('mic-btn'),
  imageBtn:     () => document.getElementById('image-btn'),
  imageInput:   () => document.getElementById('image-file-input'),
  imagePreview: () => document.getElementById('image-preview'),
  counterWrap:  () => document.getElementById('question-counter'),
  counterNum:   () => document.getElementById('counter-number'),
  counterFill:  () => document.getElementById('counter-fill'),
  topicDisplay: () => document.getElementById('topic-display'),
  exchangeNum:  () => document.getElementById('exchange-number'),
  typingRow:    () => document.getElementById('typing-indicator-row'),
  limitModal:   () => document.getElementById('limit-modal'),
};

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  State.sessionId         = document.body.dataset.sessionId || null;
  State.topic             = document.body.dataset.topic     || '';
  State.questionsRemaining = parseInt(document.body.dataset.questionsRemaining || '0', 10);
  State.questionLimit      = parseInt(document.body.dataset.questionLimit || '20', 10);

  updateQuestionCounter(State.questionsRemaining);
  _setupTextareaAutoResize();
  _setupKeyboardShortcuts();
  _setupiOSViewportFix();
  _scrollToBottom(false);
});

// ── Send Message ──────────────────────────────────────────────────────────────

async function sendMessage(type = 'text') {
  const textarea = DOM.textarea();
  const text = textarea.value.trim();
  const image = State.pendingImageB64;

  if (!text && !image) return;
  if (State.isStreaming) return;
  if (State.questionsRemaining <= 0) { handleLimitReached(); return; }

  // Validate
  if (!State.topic) { showToast('Please set a topic first.', 'error'); return; }

  // Optimistic UI — add student bubble immediately
  _appendBubble('student', text, image);
  textarea.value = '';
  textarea.style.height = 'auto';
  _clearImagePreview();

  // Disable input during stream
  State.isStreaming = true;
  DOM.sendBtn().disabled = true;
  DOM.textarea().disabled = true;

  // Show typing indicator
  _showTypingIndicator();

  // Determine input type
  const inputType = image && text ? 'combined' : image ? 'image' : type;

  // Build form data
  const formData = new FormData();
  formData.append('topic', State.topic);
  formData.append('text', text);
  formData.append('input_type', inputType);
  if (State.sessionId) formData.append('session_id', State.sessionId);
  if (image) formData.append('image', image);

  // Open SSE stream
  try {
    const resp = await fetch('/session/ask/stream', {
      method: 'POST',
      body: formData,
      headers: { 'Accept': 'text/event-stream' },
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      _handleStreamError(err.error || 'REQUEST_FAILED', err.message);
      return;
    }

    // Stream tokens
    const mirraBubble = _appendBubble('mirra', '');
    const textNode = mirraBubble.querySelector('.bubble-text');
    _hideTypingIndicator();

    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop(); // keep incomplete line

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        try {
          const event = JSON.parse(line.slice(6));
          if (event.type === 'token') {
            textNode.textContent += event.content;
            _scrollToBottom();
          } else if (event.type === 'done') {
            _finaliseResponse(event);
          } else if (event.type === 'error') {
            _handleStreamError(event.code, event.message);
          }
        } catch { /* ignore malformed SSE lines */ }
      }
    }

  } catch (e) {
    console.error('Stream error:', e);
    _handleStreamError('NETWORK_ERROR', 'Connection lost. Please try again.');
  } finally {
    State.isStreaming = false;
    DOM.sendBtn().disabled = false;
    DOM.textarea().disabled = false;
    DOM.textarea().focus();
    _hideTypingIndicator();
  }
}

function _finaliseResponse(meta) {
  if (meta.session_id && !State.sessionId) {
    State.sessionId = meta.session_id;
    document.body.dataset.sessionId = meta.session_id;
  }
  if (typeof meta.questions_remaining === 'number') {
    State.questionsRemaining = meta.questions_remaining;
    updateQuestionCounter(meta.questions_remaining);
  }
  if (meta.exchange_number && DOM.exchangeNum()) {
    DOM.exchangeNum().textContent = `Session [${meta.exchange_number}]`;
  }
  if (meta.gap_detected) {
    _showGapDetectedIndicator();
  }
}

function _handleStreamError(code, message) {
  _hideTypingIndicator();
  if (code === 'QUESTION_LIMIT_EXCEEDED') {
    handleLimitReached();
  } else {
    showToast(message || 'Something went wrong. Please try again.', 'error');
  }
  // Restore question counter — question was decremented before stream, undo
  State.questionsRemaining = Math.min(State.questionsRemaining + 1, State.questionLimit);
  updateQuestionCounter(State.questionsRemaining);
}

// ── Voice Recording ───────────────────────────────────────────────────────────

async function startRecording() {
  if (State.isRecording) {
    _stopRecording();
    return;
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    State.mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
    State.audioChunks = [];

    State.mediaRecorder.ondataavailable = e => {
      if (e.data.size > 0) State.audioChunks.push(e.data);
    };

    State.mediaRecorder.onstop = async () => {
      const blob = new Blob(State.audioChunks, { type: 'audio/webm' });
      stream.getTracks().forEach(t => t.stop());
      await _transcribeAudio(blob);
    };

    State.mediaRecorder.start(100);
    State.isRecording = true;
    DOM.micBtn().classList.add('recording');
    DOM.micBtn().setAttribute('aria-label', 'Stop recording');
    showToast('Recording… tap mic to stop.', 'warning');

    // Auto-stop after 3 minutes
    State.recordingTimer = setTimeout(() => _stopRecording(), 180_000);

  } catch (e) {
    if (e.name === 'NotAllowedError') {
      showToast('Microphone access denied. Enable it in browser settings.', 'error');
    } else {
      showToast('Could not start recording.', 'error');
    }
  }
}

function _stopRecording() {
  if (!State.isRecording || !State.mediaRecorder) return;
  clearTimeout(State.recordingTimer);
  State.mediaRecorder.stop();
  State.isRecording = false;
  DOM.micBtn().classList.remove('recording');
  DOM.micBtn().setAttribute('aria-label', 'Start recording');
}

async function _transcribeAudio(blob) {
  const sendBtn = DOM.sendBtn();
  sendBtn.disabled = true;
  showToast('Transcribing…', 'info');

  try {
    const fd = new FormData();
    fd.append('audio', blob, 'recording.webm');
    const resp = await fetch('/session/transcribe', { method: 'POST', body: fd });
    if (!resp.ok) throw new Error('Transcription failed');
    const data = await resp.json();
    if (data.text) {
      DOM.textarea().value = data.text;
      DOM.textarea().dispatchEvent(new Event('input'));
      showToast('Voice transcribed', 'success');
      sendMessage('voice');
    }
  } catch (e) {
    showToast('Could not transcribe audio. Please type instead.', 'error');
  } finally {
    sendBtn.disabled = false;
  }
}

// ── Image Upload ──────────────────────────────────────────────────────────────

function handleImageUpload(file) {
  if (!file || !file.type.startsWith('image/')) {
    showToast('Please upload an image file.', 'error');
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    showToast('Image must be under 10MB.', 'error');
    return;
  }

  const reader = new FileReader();
  reader.onload = e => {
    const b64 = e.target.result.split(',')[1]; // strip data:...;base64,
    State.pendingImageB64 = b64;

    // Show preview
    const preview = DOM.imagePreview();
    if (preview) {
      preview.innerHTML = `
        <div class="image-preview-thumb">
          <img src="${e.target.result}" alt="Uploaded image" style="max-height:80px; border-radius:8px;">
          <button onclick="_clearImagePreview()" class="icon-btn" style="width:28px;height:28px;font-size:14px;">✕</button>
        </div>`;
      preview.style.display = 'flex';
    }

    // Hint if no text
    if (!DOM.textarea().value.trim()) {
      DOM.textarea().placeholder = 'Tell me what you\'re thinking about this…';
    }
  };
  reader.readAsDataURL(file);
}

function _clearImagePreview() {
  State.pendingImageB64 = null;
  const preview = DOM.imagePreview();
  if (preview) { preview.innerHTML = ''; preview.style.display = 'none'; }
  const inp = DOM.imageInput();
  if (inp) inp.value = '';
  DOM.textarea().placeholder = 'What are you thinking about…';
}

// Support paste image from clipboard
document.addEventListener('paste', e => {
  const items = e.clipboardData?.items || [];
  for (const item of items) {
    if (item.type.startsWith('image/')) {
      handleImageUpload(item.getAsFile());
      break;
    }
  }
});

// ── Question Counter ──────────────────────────────────────────────────────────

function updateQuestionCounter(remaining) {
  const wrap = DOM.counterWrap();
  const numEl = DOM.counterNum();
  const fill = DOM.counterFill();
  if (!wrap || !numEl || !fill) return;

  const pct = Math.max(0, Math.min(100, (remaining / State.questionLimit) * 100));
  fill.style.width = pct + '%';
  numEl.textContent = remaining;

  wrap.classList.remove('counter-green', 'counter-amber', 'counter-red');
  if (pct > 20) {
    wrap.classList.add('counter-green');
  } else if (pct > 0) {
    wrap.classList.add('counter-amber');
  } else {
    wrap.classList.add('counter-red');
  }

  // Disable send if 0
  if (remaining <= 0) {
    DOM.sendBtn().disabled = true;
    DOM.sendBtn().title = 'No questions remaining — upgrade to continue';
  }
}

// ── Upgrade Modal ─────────────────────────────────────────────────────────────

function handleLimitReached() {
  const modal = DOM.limitModal();
  if (modal) { modal.classList.remove('hidden'); return; }

  // Create inline if template not present
  const el = document.createElement('div');
  el.id = 'limit-modal';
  el.className = 'modal-backdrop';
  el.innerHTML = `
    <div class="modal-card">
      <div class="modal-title">You've used all your questions for this month 🌿</div>
      <div class="modal-body">
        Your thinking work is paused until questions reset.
      </div>
      <div class="modal-actions">
        <a href="/pricing" class="btn btn-primary btn-full">Upgrade now</a>
        <button onclick="document.getElementById('limit-modal').classList.add('hidden')" class="btn btn-ghost btn-full" style="margin-top:8px">Maybe later</button>
      </div>
    </div>`;
  document.body.appendChild(el);
}

// ── Bubble Helpers ────────────────────────────────────────────────────────────

function _appendBubble(role, text, imageB64 = null) {
  const area = DOM.conversation();
  const row = document.createElement('div');
  row.className = `bubble-row ${role === 'student' ? 'student' : 'mirra'}`;

  let content = '';
  if (imageB64) {
    content += `<img src="data:image/jpeg;base64,${imageB64}" alt="Your image"
      style="max-width:200px;border-radius:8px;margin-bottom:8px;display:block;">`;
  }
  content += `<span class="bubble-text">${_escapeHTML(text)}</span>`;

  row.innerHTML = `
    <div class="bubble bubble-${role === 'student' ? 'student' : 'mirra'}">
      ${content}
    </div>`;

  area.appendChild(row);
  _scrollToBottom();
  return row.querySelector('.bubble');
}

function _escapeHTML(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function _showTypingIndicator() {
  const row = DOM.typingRow();
  if (row) { row.style.display = 'flex'; _scrollToBottom(); return; }

  const area = DOM.conversation();
  const el = document.createElement('div');
  el.id = 'typing-indicator-row';
  el.className = 'bubble-row mirra';
  el.innerHTML = `
    <div class="typing-indicator">
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    </div>`;
  area.appendChild(el);
  _scrollToBottom();
}

function _hideTypingIndicator() {
  const row = document.getElementById('typing-indicator-row');
  if (row) row.remove();
}

function _showGapDetectedIndicator() {
  showToast('Mirra noticed a thinking pattern — check your dashboard.', 'info');
}

function _scrollToBottom(smooth = true) {
  const area = DOM.conversation();
  if (!area) return;
  area.scrollTo({ top: area.scrollHeight, behavior: smooth ? 'smooth' : 'instant' });
}

// ── Textarea Auto-resize ───────────────────────────────────────────────────────

function _setupTextareaAutoResize() {
  const ta = DOM.textarea();
  if (!ta) return;
  const resize = () => {
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
  };
  ta.addEventListener('input', resize);
}

// ── Keyboard Shortcuts ────────────────────────────────────────────────────────

function _setupKeyboardShortcuts() {
  document.addEventListener('keydown', e => {
    const ta = DOM.textarea();
    if (document.activeElement !== ta) return;
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
}

// ── iOS Keyboard Viewport Fix ─────────────────────────────────────────────────

function _setupiOSViewportFix() {
  if (!/iPhone|iPad/.test(navigator.userAgent)) return;
  window.addEventListener('focusin', () => document.body.classList.add('keyboard-open'));
  window.addEventListener('focusout', () => document.body.classList.remove('keyboard-open'));
  // Fix 100vh bug on iOS Safari
  const setVH = () => document.documentElement.style.setProperty('--vh', window.innerHeight * 0.01 + 'px');
  window.addEventListener('resize', setVH);
  setVH();
}

// ── Toast Utility ─────────────────────────────────────────────────────────────

function showToast(message, type = 'info', duration = 4000) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || 'ℹ'}</span>
    <span class="toast-text">${_escapeHTML(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 200ms';
    setTimeout(() => toast.remove(), 220);
  }, duration);
}

// ── Conversation Export ───────────────────────────────────────────────────────

function exportConversation() {
  window.print();
}

// Expose to HTML onclick attributes
window.sendMessage         = sendMessage;
window.startRecording      = startRecording;
window.handleImageUpload   = handleImageUpload;
window.updateQuestionCounter = updateQuestionCounter;
window.handleLimitReached  = handleLimitReached;
window.showToast           = showToast;
window.exportConversation  = exportConversation;
window._clearImagePreview  = _clearImagePreview;
