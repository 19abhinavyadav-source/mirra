"""
ai/ask_handler.py — Core Socratic session processing pipeline.

Flow per student message:
  1. Classify query type (Haiku, fast)
  2. Build personalized system prompt
  3. Decrement question counter (before API call — prevents free rides)
  4. Call Claude Sonnet with streaming
  5. After stream: extract gap, save exchange, update session state
"""

import json
import logging
import time
from datetime import datetime, timezone
from typing import Generator, Optional

from flask import current_app

from ai.mirra_brain import (
    QUERY_CLASSIFICATION_PROMPT,
    GAP_DETECTION_PROMPT,
    build_ib_prompt,
    get_depth_calibration,
)
from ai.orchestrator import call_claude, call_claude_json, SONNET_TASKS
from ai.conversation import ConversationManager
from extensions import db, redis_client
from models import Session, Exchange, IbGap, User

logger = logging.getLogger(__name__)


# ── Public entry point ────────────────────────────────────────────────────────

def handle_ask_stream(
    user: User,
    topic: str,
    student_input: str,
    session_id: Optional[str],
    input_type: str = "text",
    image_b64: Optional[str] = None,
) -> Generator[str, None, None]:
    """
    Full streaming pipeline. Yields SSE-formatted strings.

    Usage (Flask route):
        return Response(
            handle_ask_stream(...),
            mimetype="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )
    """
    start_ms = int(time.time() * 1000)

    # ── 1. Get or create session ─────────────────────────────────────────────
    session = _get_or_create_session(user, topic, session_id)
    conv_mgr = ConversationManager(session.id)

    # ── 2. Classify query type (Haiku, free) ──────────────────────────────────
    try:
        classification = call_claude_json(
            task="query_classification",
            prompt=QUERY_CLASSIFICATION_PROMPT.format(
                student_input=student_input[:2000],
                programme=user.programme or "IB",
                active_assessment=user.active_assessment or "EXAM_PREP",
            ),
            user_id=user.id,
        )
        query_type = classification.get("query_type", "general_question")
        emotional_signal = classification.get("emotional_signal", "none")
        input_level = classification.get("input_level", "has_foundation")
    except Exception as e:
        logger.warning(f"Classification failed, using defaults: {e}")
        query_type = "general_question"
        emotional_signal = "none"
        input_level = "has_foundation"

    # ── 3. Build personalized system prompt ───────────────────────────────────
    depth = get_depth_calibration(user.session_count or 0)
    system_prompt = build_ib_prompt(user, depth_calibration=depth)

    # ── 4. Build conversation history ────────────────────────────────────────
    history = conv_mgr.get_history()

    # Build current user message (may include image)
    if image_b64:
        user_content = [
            {
                "type": "image",
                "source": {"type": "base64", "media_type": "image/jpeg", "data": image_b64},
            },
            {"type": "text", "text": student_input},
        ]
    else:
        user_content = student_input

    messages = history + [{"role": "user", "content": user_content}]

    # Limit context: never exceed 80K tokens (rough heuristic: 200 chars ≈ 50 tokens)
    while len(json.dumps(messages)) > 300_000 and len(messages) > 2:
        messages = messages[2:]  # drop oldest pair

    # ── 5. Decrement question counter BEFORE API call ─────────────────────────
    user.decrement_question()
    db.session.commit()

    # ── 6. Stream response from Claude Sonnet ────────────────────────────────
    full_response = ""
    question_type_used = None

    try:
        import anthropic as _ant
        client = _ant.Anthropic(api_key=current_app.config["ANTHROPIC_API_KEY"])

        with client.messages.stream(
            model=current_app.config["CLAUDE_SONNET_MODEL"],
            max_tokens=250,
            system=system_prompt,
            messages=messages,
        ) as stream:
            for text_chunk in stream.text_stream:
                full_response += text_chunk
                yield _sse("token", {"content": text_chunk})

            final_msg = stream.get_final_message()
            tokens_in = final_msg.usage.input_tokens
            tokens_out = final_msg.usage.output_tokens

        # ── 7. Post-stream: extract gap, save exchange ───────────────────────
        gap = _extract_gap_from_response(full_response)
        question_type_used = _detect_question_type(full_response)

        latency_ms = int(time.time() * 1000) - start_ms

        exchange = _save_exchange(
            session=session,
            student_input=student_input,
            mirra_response=full_response,
            input_type=input_type,
            query_type=query_type,
            question_type_used=question_type_used,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            has_image=bool(image_b64),
        )

        # Store gap if detected
        gap_detected = False
        if gap:
            gap_detected = True
            _store_gap(user=user, session=session, gap_data=gap, exchange_number=exchange.exchange_number)

        # Update conversation memory
        conv_mgr.add_exchange(student_input, full_response)

        # Check for progress state every 5 exchanges
        if exchange.exchange_number % 5 == 0:
            _async_run_progress_check(session, conv_mgr)

        yield _sse("done", {
            "questions_remaining": user.questions_remaining(),
            "gap_detected": gap_detected,
            "session_id": session.id,
            "exchange_number": exchange.exchange_number,
        })

    except _ant.APIError as e:
        # Restore question counter on API failure
        user.monthly_questions_used = max(0, user.monthly_questions_used - 1)
        if user.plan == "trial":
            user.trial_questions_used = max(0, user.trial_questions_used - 1)
        db.session.commit()
        logger.error(f"Anthropic API error in ask_handler: {e}")
        yield _sse("error", {
            "message": "Mirra is taking a moment — please try again.",
            "code": "API_ERROR",
        })
    except Exception as e:
        logger.error(f"Unexpected error in ask_handler: {e}", exc_info=True)
        yield _sse("error", {"message": "Something went wrong.", "code": "UNKNOWN_ERROR"})


# ── Helpers ───────────────────────────────────────────────────────────────────

def _sse(event_type: str, data: dict) -> str:
    return f"data: {json.dumps({'type': event_type, **data})}\n\n"


def _get_or_create_session(user: User, topic: str, session_id: Optional[str]) -> Session:
    if session_id:
        session = Session.query.filter_by(id=session_id, user_id=user.id).first()
        if session:
            return session

    session = Session(
        user_id=user.id,
        topic=topic[:500],
        assessment_context=user.active_assessment,
        subject=_infer_subject(topic, user.subjects),
    )
    db.session.add(session)
    user.session_count = (user.session_count or 0) + 1
    db.session.commit()
    return session


def _save_exchange(session, student_input, mirra_response, input_type,
                   query_type, question_type_used, tokens_in, tokens_out,
                   latency_ms, has_image) -> Exchange:
    from ai.orchestrator import _calc_cost
    cost = _calc_cost("claude-sonnet-4-5", tokens_in, tokens_out)

    session.exchange_count = (session.exchange_count or 0) + 1
    session.total_tokens_used = (session.total_tokens_used or 0) + tokens_in + tokens_out
    session.total_cost_paise = (session.total_cost_paise or 0) + cost

    exchange = Exchange(
        session_id=session.id,
        exchange_number=session.exchange_count,
        student_input=student_input[:5000],
        mirra_response=mirra_response,
        input_type=input_type,
        query_type=query_type,
        question_type_used=question_type_used,
        tokens_input=tokens_in,
        tokens_output=tokens_out,
        model_used="claude-sonnet-4-5",
        response_time_ms=latency_ms,
        cost_paise=cost,
        has_image=has_image,
    )
    db.session.add(exchange)
    db.session.commit()
    return exchange


def _extract_gap_from_response(response_text: str) -> Optional[dict]:
    """
    If response contains a [GAP: ...] marker (hidden from student, extracted here),
    use gap detection prompt to get structured data from the session.
    Returns gap dict or None.
    """
    # The gap marker is injected by the model every 5 exchanges
    # For now check if text mentions reasoning gaps indicatively
    return None  # full gap extraction done via detect_gaps_async every 5 exchanges


def _detect_question_type(response: str) -> Optional[str]:
    """Heuristically detect which question type was used in Mirra's response."""
    response_lower = response.lower()
    if "assuming" in response_lower or "assumption" in response_lower:
        return "TYPE_A"
    if "if that" in response_lower or "what would follow" in response_lower:
        return "TYPE_B"
    if "case where" in response_lower or "wouldn't hold" in response_lower:
        return "TYPE_C"
    if "what do you mean" in response_lower or "define" in response_lower:
        return "TYPE_D"
    if "evidence" in response_lower or "point to" in response_lower:
        return "TYPE_E"
    if "disagrees" in response_lower or "other side" in response_lower:
        return "TYPE_F"
    if "what would happen if" in response_lower or "imagine" in response_lower:
        return "TYPE_G"
    return None


def _store_gap(user, session, gap_data: dict, exchange_number: int):
    """Save or increment a detected reasoning gap."""
    try:
        existing = IbGap.query.filter_by(
            user_id=user.id,
            gap_category=gap_data.get("gap_category"),
            is_dismissed=False,
        ).first()

        if existing:
            existing.occurrence_count += 1
            existing.last_seen_at = datetime.now(timezone.utc)
            existing.session_id = session.id
        else:
            new_gap = IbGap(
                user_id=user.id,
                session_id=session.id,
                exchange_number=exchange_number,
                gap_text=gap_data.get("gap_text", ""),
                gap_category=gap_data.get("gap_category", "other"),
                confidence=gap_data.get("confidence", "medium"),
                evidence_quote=gap_data.get("evidence", ""),
                subject=session.subject,
                assessment_type=session.assessment_context,
            )
            db.session.add(new_gap)
        db.session.commit()
    except Exception as e:
        logger.error(f"Gap storage failed: {e}")
        db.session.rollback()


def _infer_subject(topic: str, subjects: Optional[list]) -> Optional[str]:
    if not subjects:
        return None
    topic_lower = topic.lower()
    for subj in subjects:
        if subj.lower() in topic_lower:
            return subj
    return subjects[0] if subjects else None


def _async_run_progress_check(session, conv_mgr):
    """Run progress state assessment (non-blocking best-effort)."""
    try:
        from ai.mirra_brain import PROGRESS_STATE_PROMPT
        segment = conv_mgr.get_recent_segment(5)
        result = call_claude_json(
            task="progress_assessment",
            prompt=PROGRESS_STATE_PROMPT.format(conversation_segment=segment),
        )
        state = result.get("state", "DEEPENING")
        session.final_state = state
        if state == "BREAKTHROUGH":
            session.breakthrough_achieved = True
        db.session.commit()
    except Exception as e:
        logger.warning(f"Progress check failed (non-critical): {e}")


def detect_gaps_for_session(session_id: str, user_id: str):
    """
    Full gap detection pass using Haiku — called asynchronously every 5 exchanges.
    This is the proper implementation of SE-02.
    """
    try:
        session = Session.query.get(session_id)
        if not session:
            return

        exchanges = (
            Exchange.query
            .filter_by(session_id=session_id)
            .order_by(Exchange.exchange_number)
            .all()
        )
        if len(exchanges) < 3:
            return

        # Build conversation segment
        segment = "\n".join(
            f"Student: {e.student_input}\nMirra: {e.mirra_response}"
            for e in exchanges[-5:]
        )

        result = call_claude_json(
            task="gap_detection",
            prompt=GAP_DETECTION_PROMPT.format(
                conversation_segment=segment,
                subject=session.subject or "General",
                assessment_type=session.assessment_context or "EXAM_PREP",
            ),
            user_id=user_id,
        )

        if result.get("gap_detected") and result.get("confidence") != "low":
            user = User.query.get(user_id)
            _store_gap(user=user, session=session, gap_data=result,
                       exchange_number=len(exchanges))
    except Exception as e:
        logger.error(f"Gap detection for session {session_id} failed: {e}")
