"""
ai/conversation.py — Conversation state machine and session memory.

Manages:
  - Conversation history (cached in Redis, sourced from DB)
  - Progress state: DEEPENING / SURFACE / STUCK / BREAKTHROUGH / CIRCULAR
  - Session energy tracking
"""

import json
import logging
from typing import List, Optional

from extensions import redis_client

logger = logging.getLogger(__name__)

# Redis TTL for conversation cache: 2 hours of inactivity closes session
CONV_TTL_SECONDS = 7200

# Maximum history exchanges to keep in active context
MAX_HISTORY_PAIRS = 10


class ConversationManager:
    """
    Manages the live conversation for a single tutoring session.

    Uses Redis as a write-through cache.
    Falls back to PostgreSQL on cache miss.
    """

    def __init__(self, session_id: str):
        self.session_id = session_id
        self._cache_key = f"conv:{session_id}"

    # ── History ───────────────────────────────────────────────────────────────

    def get_history(self) -> List[dict]:
        """Return conversation history as Claude messages format."""
        cached = redis_client.get(self._cache_key)
        if cached:
            try:
                return json.loads(cached)
            except json.JSONDecodeError:
                pass

        # Cache miss — load from DB
        return self._load_from_db()

    def add_exchange(self, student_input: str, mirra_response: str):
        """Append a new exchange to history and refresh cache."""
        history = self.get_history()

        history.append({"role": "user", "content": student_input})
        history.append({"role": "assistant", "content": mirra_response})

        # Trim to max window
        if len(history) > MAX_HISTORY_PAIRS * 2:
            history = history[-(MAX_HISTORY_PAIRS * 2):]

        self._write_cache(history)

    def get_recent_segment(self, last_n: int = 5) -> str:
        """Return last N exchanges as plain text for gap/progress analysis."""
        history = self.get_history()
        # history is [user, assistant, user, assistant, ...]
        pairs = []
        for i in range(0, len(history) - 1, 2):
            user_msg = history[i].get("content", "")
            asst_msg = history[i + 1].get("content", "") if i + 1 < len(history) else ""
            if isinstance(user_msg, list):
                user_msg = " ".join(
                    part.get("text", "") for part in user_msg if part.get("type") == "text"
                )
            pairs.append(f"Student: {user_msg}\nMirra: {asst_msg}")

        recent = pairs[-last_n:] if len(pairs) >= last_n else pairs
        return "\n\n".join(recent)

    def clear(self):
        """Clear session cache (on session close)."""
        redis_client.delete(self._cache_key)

    # ── Private ───────────────────────────────────────────────────────────────

    def _load_from_db(self) -> List[dict]:
        """Load conversation history from PostgreSQL exchanges table."""
        try:
            from models import Exchange
            exchanges = (
                Exchange.query
                .filter_by(session_id=self.session_id)
                .order_by(Exchange.exchange_number)
                .limit(MAX_HISTORY_PAIRS)
                .all()
            )
            history = []
            for ex in exchanges:
                history.append({"role": "user", "content": ex.student_input})
                history.append({"role": "assistant", "content": ex.mirra_response})
            self._write_cache(history)
            return history
        except Exception as e:
            logger.warning(f"DB history load failed for session {self.session_id}: {e}")
            return []

    def _write_cache(self, history: List[dict]):
        try:
            redis_client.setex(self._cache_key, CONV_TTL_SECONDS, json.dumps(history))
        except Exception as e:
            logger.warning(f"Redis cache write failed: {e}")


# ── Progress State Machine ─────────────────────────────────────────────────────

class ProgressState:
    DEEPENING = "DEEPENING"
    SURFACE = "SURFACE"
    STUCK = "STUCK"
    BREAKTHROUGH = "BREAKTHROUGH"
    CIRCULAR = "CIRCULAR"

    _state_key = "progress:{session_id}"

    @classmethod
    def get(cls, session_id: str) -> str:
        try:
            state = redis_client.get(f"progress:{session_id}")
            return state or cls.SURFACE
        except Exception:
            return cls.SURFACE

    @classmethod
    def set(cls, session_id: str, state: str):
        try:
            redis_client.setex(f"progress:{session_id}", CONV_TTL_SECONDS, state)
        except Exception as e:
            logger.warning(f"Progress state write failed: {e}")

    @classmethod
    def transition(cls, session_id: str, new_state: str, session=None):
        """Update state and persist to DB session if provided."""
        cls.set(session_id, new_state)
        if session:
            session.final_state = new_state
            if new_state == cls.BREAKTHROUGH:
                session.breakthrough_achieved = True


# ── Socratic Stage Detector ───────────────────────────────────────────────────

def detect_stage(exchange_count: int, progress_state: str) -> str:
    """
    Return the current questioning stage based on exchange count and progress.
    Stages: PROBE → NUDGE → PIVOT → BRIDGE
    """
    if progress_state == ProgressState.BREAKTHROUGH:
        return "BRIDGE"
    if progress_state == ProgressState.STUCK and exchange_count >= 4:
        return "PIVOT"
    if exchange_count <= 2:
        return "PROBE"
    if exchange_count <= 5:
        return "NUDGE"
    return "PIVOT"
