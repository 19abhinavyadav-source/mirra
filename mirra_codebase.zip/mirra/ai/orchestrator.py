"""
ai/orchestrator.py — LLM Orchestration Layer (AI-01)

Routes tasks to the correct Claude model, tracks costs, enforces circuit breakers.
ALL Claude API calls go through call_claude() — never call anthropic directly.
"""

import json
import time
import logging
from typing import Generator, Optional, Union

import anthropic
from flask import current_app

from extensions import db, redis_client
from models import ApiCall

logger = logging.getLogger(__name__)

# ── Cost constants (paise per 1K tokens) ─────────────────────────────────────
COST_TABLE = {
    "claude-sonnet-4-5": {"input": 70, "output": 350},       # ₹0.70/1K in, ₹3.50/1K out
    "claude-haiku-4-5-20251001": {"input": 4, "output": 20},  # ₹0.04/1K in, ₹0.20/1K out
}

# ── Task → Model routing table (AI-01) ───────────────────────────────────────
TASK_MODEL_MAP = {
    # Sonnet — counts as student question
    "tutoring_session":   "claude-sonnet-4-5",
    "weekly_report":      "claude-sonnet-4-5",
    "breakthrough_message": "claude-sonnet-4-5",

    # Haiku — free, no question deduction
    "query_classification":  "claude-haiku-4-5-20251001",
    "progress_assessment":   "claude-haiku-4-5-20251001",
    "gap_detection":         "claude-haiku-4-5-20251001",
    "energy_check":          "claude-haiku-4-5-20251001",
    "morning_checkin":       "claude-haiku-4-5-20251001",
    "deadline_nudge":        "claude-haiku-4-5-20251001",
    "session_summary":       "claude-haiku-4-5-20251001",
    "misconception_flag":    "claude-haiku-4-5-20251001",
}

TASK_MAX_TOKENS = {
    "tutoring_session":      250,
    "weekly_report":         600,
    "query_classification":  80,
    "gap_detection":         150,
    "progress_assessment":   60,
    "energy_check":          40,
    "morning_checkin":       120,
    "deadline_nudge":        80,
    "session_summary":       200,
    "misconception_flag":    50,
    "breakthrough_message":  150,
}

SONNET_TASKS = {"tutoring_session", "weekly_report", "breakthrough_message"}


def get_claude_model(task: str) -> str:
    """Return the model string for a given task."""
    model = TASK_MODEL_MAP.get(task, "claude-haiku-4-5-20251001")
    logger.debug(f"Task={task} → model={model}")
    return model


def call_claude(
    task: str,
    messages: list,
    system_prompt: str = "",
    stream: bool = False,
    user_id: Optional[str] = None,
    prompt_version: Optional[str] = None,
) -> Union[str, Generator]:
    """
    Single entry point for all Claude API calls.

    Args:
        task:           one of the keys in TASK_MODEL_MAP
        messages:       OpenAI-style messages list [{"role": ..., "content": ...}]
        system_prompt:  system prompt string
        stream:         if True, return a generator of text chunks
        user_id:        for cost tracking / circuit breaker
        prompt_version: for A/B tracking

    Returns:
        str if stream=False, generator if stream=True
    """
    _check_circuit_breaker(user_id)

    client = anthropic.Anthropic(api_key=current_app.config["ANTHROPIC_API_KEY"])
    model = get_claude_model(task)
    max_tokens = TASK_MAX_TOKENS.get(task, 250)
    start_ms = int(time.time() * 1000)

    kwargs = dict(
        model=model,
        max_tokens=max_tokens,
        messages=messages,
    )
    if system_prompt:
        kwargs["system"] = system_prompt

    try:
        if stream:
            return _stream_generator(client, kwargs, task, model, user_id, prompt_version, start_ms)
        else:
            response = client.messages.create(**kwargs)
            latency = int(time.time() * 1000) - start_ms
            text = response.content[0].text
            cost = _calc_cost(model, response.usage.input_tokens, response.usage.output_tokens)
            _log_api_call(
                task=task, model=model, user_id=user_id,
                tokens_in=response.usage.input_tokens,
                tokens_out=response.usage.output_tokens,
                cost_paise=cost, latency_ms=latency,
                success=True, prompt_version=prompt_version,
            )
            _track_daily_spend(cost, user_id)
            return text

    except anthropic.RateLimitError as e:
        logger.error(f"Rate limit hit for task={task}: {e}")
        _log_api_call(task=task, model=model, user_id=user_id, success=False, error_code="RATE_LIMIT")
        raise
    except anthropic.APIError as e:
        logger.error(f"API error for task={task}: {e}")
        _log_api_call(task=task, model=model, user_id=user_id, success=False, error_code="API_ERROR")
        raise
    except Exception as e:
        logger.error(f"Unexpected error for task={task}: {e}")
        _log_api_call(task=task, model=model, user_id=user_id, success=False, error_code="UNKNOWN")
        raise


def _stream_generator(client, kwargs, task, model, user_id, prompt_version, start_ms):
    """Yield text chunks and log cost after stream completes."""
    with client.messages.stream(**kwargs) as stream:
        full_text = ""
        for text_chunk in stream.text_stream:
            full_text += text_chunk
            yield text_chunk

        final = stream.get_final_message()
        latency = int(time.time() * 1000) - start_ms
        cost = _calc_cost(model, final.usage.input_tokens, final.usage.output_tokens)
        _log_api_call(
            task=task, model=model, user_id=user_id,
            tokens_in=final.usage.input_tokens,
            tokens_out=final.usage.output_tokens,
            cost_paise=cost, latency_ms=latency,
            success=True, prompt_version=prompt_version,
        )
        _track_daily_spend(cost, user_id)


def _calc_cost(model: str, tokens_in: int, tokens_out: int) -> int:
    """Return cost in paise."""
    rates = COST_TABLE.get(model, {"input": 70, "output": 350})
    return (tokens_in * rates["input"] + tokens_out * rates["output"]) // 1000


def _log_api_call(**kwargs):
    """Persist API call record for cost monitoring."""
    try:
        record = ApiCall(**{k: v for k, v in kwargs.items() if v is not None})
        db.session.add(record)
        db.session.commit()
    except Exception as e:
        logger.warning(f"Failed to log API call: {e}")
        db.session.rollback()


def _track_daily_spend(cost_paise: int, user_id: Optional[str]):
    """Increment daily spend counters in Redis."""
    try:
        from datetime import date
        today = date.today().isoformat()
        redis_client.incrby(f"daily_spend:{today}", cost_paise)
        redis_client.expire(f"daily_spend:{today}", 86400 * 2)
        if user_id:
            redis_client.incrby(f"user_spend:{user_id}:{today}", cost_paise)
            redis_client.expire(f"user_spend:{user_id}:{today}", 86400 * 2)
    except Exception as e:
        logger.warning(f"Redis spend tracking failed: {e}")


def _check_circuit_breaker(user_id: Optional[str]):
    """Raise if daily spend exceeds configured threshold."""
    try:
        from datetime import date
        today = date.today().isoformat()
        daily_total = int(redis_client.get(f"daily_spend:{today}") or 0)
        alert_threshold = current_app.config.get("DAILY_SPEND_ALERT_PAISE", 200000)

        if daily_total > alert_threshold:
            logger.critical(f"DAILY SPEND ALERT: {daily_total} paise today")
            # send_admin_alert(f"Daily spend alert: ₹{daily_total/100:.0f} today")
    except Exception:
        pass  # never let circuit breaker checking break the app


def call_claude_json(task: str, prompt: str, user_id: Optional[str] = None) -> dict:
    """
    Convenience wrapper for Haiku JSON-only calls (classification, gap detection, etc.)
    Returns parsed dict or raises ValueError on bad JSON.
    """
    raw = call_claude(
        task=task,
        messages=[{"role": "user", "content": prompt}],
        user_id=user_id,
    )
    try:
        # Strip markdown fences if model wraps them
        clean = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        return json.loads(clean)
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse failed for task={task}: {e}\nRaw: {raw}")
        raise ValueError(f"Model returned non-JSON for {task}: {raw[:200]}")
