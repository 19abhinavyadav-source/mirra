"""
extensions.py — Flask extension instances (initialised before the app factory).
"""

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
import redis
import os

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

# Redis — lazy connection; actual URL injected by app factory via config
def _make_redis():
    url = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
    return redis.from_url(url, decode_responses=True)

redis_client = _make_redis()
