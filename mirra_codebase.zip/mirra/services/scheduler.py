"""
services/scheduler.py — APScheduler background jobs (BE-02).

Jobs:
  1. morning_checkin          — 8:00 AM IST daily
  2. deadline_countdown_nudge — 7:00 PM IST daily
  3. sunday_weekly_report     — 6:00 PM IST every Sunday
  4. monthly_question_reset   — 1:00 AM IST, 1st of every month
  5. trial_expiry_nudge       — every hour
  6. health_check_ping        — every 5 minutes
"""

import logging
from datetime import datetime, timezone, timedelta, date

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

logger = logging.getLogger(__name__)


def start_scheduler(app):
    scheduler = BackgroundScheduler(timezone="Asia/Kolkata")

    scheduler.add_job(
        func=lambda: _run_job(app, morning_checkin),
        trigger=CronTrigger(hour=8, minute=0),
        id="morning_checkin", replace_existing=True,
    )
    scheduler.add_job(
        func=lambda: _run_job(app, deadline_countdown_nudge),
        trigger=CronTrigger(hour=19, minute=0),
        id="deadline_countdown_nudge", replace_existing=True,
    )
    scheduler.add_job(
        func=lambda: _run_job(app, sunday_weekly_report),
        trigger=CronTrigger(day_of_week="sun", hour=18, minute=0),
        id="sunday_weekly_report", replace_existing=True,
    )
    scheduler.add_job(
        func=lambda: _run_job(app, monthly_question_reset),
        trigger=CronTrigger(day=1, hour=1, minute=0),
        id="monthly_question_reset", replace_existing=True,
    )
    scheduler.add_job(
        func=lambda: _run_job(app, trial_expiry_nudge),
        trigger=CronTrigger(minute=0),  # every hour on the hour
        id="trial_expiry_nudge", replace_existing=True,
    )
    scheduler.add_job(
        func=lambda: _run_job(app, health_check_ping),
        trigger=CronTrigger(minute="*/5"),  # every 5 minutes
        id="health_check_ping", replace_existing=True,
    )

    scheduler.start()
    logger.info("APScheduler started with 6 jobs")
    return scheduler


def _run_job(app, job_fn):
    """Run a job inside the app context, log results."""
    with app.app_context():
        from models import JobsLog
        from extensions import db
        started = datetime.now(timezone.utc)
        log = JobsLog(job_name=job_fn.__name__, started_at=started)
        db.session.add(log)
        db.session.commit()
        try:
            processed, failures = job_fn()
            log.completed_at = datetime.now(timezone.utc)
            log.users_processed = processed
            log.failures = failures
            log.success = True
            db.session.commit()
        except Exception as e:
            logger.exception(f"Job {job_fn.__name__} FAILED: {e}")
            log.completed_at = datetime.now(timezone.utc)
            log.success = False
            log.notes = str(e)[:1000]
            db.session.commit()
            _alert_admin(f"Job {job_fn.__name__} failed: {e}")


# ── Job 1: Morning Check-in ───────────────────────────────────────────────────

def morning_checkin():
    from models import User, CheckIn
    from extensions import db, redis_client
    from ai.orchestrator import call_claude
    from ai.mirra_brain import MORNING_CHECKIN_PROMPT

    users = User.query.filter(User.is_active == True, User.is_onboarded == True).all()
    processed = failures = 0

    for user in users:
        try:
            today = date.today().isoformat()
            dedup_key = f"checkin_sent:{user.id}:{today}"
            if redis_client.exists(dedup_key):
                continue

            # Build check-in message via Haiku
            recent_gap = _get_recent_gap(user)
            last_topic = _get_last_topic(user)

            msg = call_claude(
                task="morning_checkin",
                messages=[{"role": "user", "content": MORNING_CHECKIN_PROMPT.format(
                    name=user.name or "there",
                    programme=user.programme or "IB",
                    active_assessment=user.active_assessment or "EXAM_PREP",
                    recent_gap=recent_gap or "None yet",
                    last_topic=last_topic or "your studies",
                )}],
                user_id=user.id,
            )

            checkin = CheckIn(user_id=user.id, message=msg, delivery_method="push")
            db.session.add(checkin)
            db.session.commit()

            # Mark sent (24-hour TTL)
            redis_client.setex(dedup_key, 86400, "1")
            processed += 1

        except Exception as e:
            logger.error(f"Check-in failed for user {user.id}: {e}")
            failures += 1

    return processed, failures


# ── Job 2: Deadline Nudge ─────────────────────────────────────────────────────

def deadline_countdown_nudge():
    from models import User
    from datetime import timezone

    now = datetime.now(timezone.utc)
    deadline_cutoff = now + timedelta(days=7)

    users = User.query.filter(
        User.is_active == True,
        User.assessment_deadline.isnot(None),
        User.assessment_deadline <= deadline_cutoff,
        User.assessment_deadline >= now,
    ).all()

    processed = failures = 0
    for user in users:
        try:
            days_left = (user.assessment_deadline - now).days
            logger.info(f"Nudge: {user.id} — {days_left} days until {user.active_assessment}")
            processed += 1
        except Exception as e:
            logger.error(f"Nudge failed for {user.id}: {e}")
            failures += 1

    return processed, failures


# ── Job 3: Sunday Weekly Report ───────────────────────────────────────────────

def sunday_weekly_report():
    from models import User, Session, IbGap, WeeklyReport
    from extensions import db
    from ai.orchestrator import call_claude
    from ai.mirra_brain import WEEKLY_REPORT_PROMPT
    from datetime import timezone

    now = datetime.now(timezone.utc)
    week_ago = now - timedelta(days=7)
    week_start = (now - timedelta(days=7)).date()

    # Users with ≥2 sessions this week
    from sqlalchemy import func
    active_users = (
        User.query
        .join(Session, User.id == Session.user_id)
        .filter(Session.started_at >= week_ago)
        .group_by(User.id)
        .having(func.count(Session.id) >= 2)
        .all()
    )

    processed = failures = 0
    BATCH_SIZE = 20

    for i in range(0, len(active_users), BATCH_SIZE):
        batch = active_users[i:i + BATCH_SIZE]
        for user in batch:
            try:
                sessions = Session.query.filter(
                    Session.user_id == user.id,
                    Session.started_at >= week_ago,
                ).all()

                topics = ", ".join(s.topic[:50] for s in sessions[:5])
                breakthroughs = sum(1 for s in sessions if s.breakthrough_achieved)
                gaps = IbGap.query.filter_by(user_id=user.id, is_dismissed=False)\
                    .order_by(IbGap.occurrence_count.desc()).limit(3).all()
                gaps_summary = "; ".join(g.gap_text for g in gaps) or "None detected yet"

                report_text = call_claude(
                    task="weekly_report",
                    messages=[{"role": "user", "content": WEEKLY_REPORT_PROMPT.format(
                        name=user.name or "Student",
                        programme=user.programme or "IB",
                        session_count=len(sessions),
                        topics_list=topics,
                        gaps_summary=gaps_summary,
                        breakthroughs_summary=f"{breakthroughs} breakthrough(s)" if breakthroughs else "None this week",
                    )}],
                    user_id=user.id,
                )

                report = WeeklyReport(
                    user_id=user.id,
                    week_start=week_start,
                    sessions_count=len(sessions),
                    breakthroughs_count=breakthroughs,
                    top_gap_summary=gaps_summary[:500],
                    report_text=report_text,
                )
                db.session.add(report)
                db.session.commit()
                processed += 1

            except Exception as e:
                logger.error(f"Weekly report failed for {user.id}: {e}")
                db.session.rollback()
                failures += 1

    return processed, failures


# ── Job 4: Monthly Question Reset ─────────────────────────────────────────────

def monthly_question_reset():
    from models import User
    from extensions import db
    from datetime import timezone
    from dateutil.relativedelta import relativedelta

    now = datetime.now(timezone.utc)
    next_reset = now + relativedelta(months=1)

    paid_users = User.query.filter(User.plan.in_(["basic", "pro", "elite"])).all()
    processed = failures = 0

    for user in paid_users:
        try:
            prev_count = user.monthly_questions_used
            user.monthly_questions_used = 0
            user.questions_reset_at = next_reset
            logger.info(f"Reset questions for {user.id}: was {prev_count}")
            processed += 1
        except Exception as e:
            logger.error(f"Question reset failed for {user.id}: {e}")
            failures += 1

    db.session.commit()
    return processed, failures


# ── Job 5: Trial Expiry Nudge ────────────────────────────────────────────────

def trial_expiry_nudge():
    from models import User
    from extensions import db
    from datetime import timezone

    now = datetime.now(timezone.utc)
    window_start = now + timedelta(hours=23)
    window_end = now + timedelta(hours=25)

    expiring_soon = User.query.filter(
        User.plan == "trial",
        User.trial_nudge_sent == False,
        User.trial_started_at.isnot(None),
    ).all()

    processed = failures = 0
    for user in expiring_soon:
        try:
            trial_end = user.trial_started_at + timedelta(days=7)
            if window_start <= trial_end <= window_end:
                user.trial_nudge_sent = True
                logger.info(f"Trial expiry nudge sent to {user.id}")
                processed += 1
        except Exception as e:
            logger.error(f"Trial nudge failed for {user.id}: {e}")
            failures += 1

    db.session.commit()
    return processed, failures


# ── Job 6: Health Check ───────────────────────────────────────────────────────

def health_check_ping():
    from extensions import db, redis_client

    failures = 0
    try:
        db.session.execute(db.text("SELECT 1"))
    except Exception as e:
        logger.critical(f"DB health check FAILED: {e}")
        _alert_admin(f"DB health check failed: {e}")
        failures += 1

    try:
        redis_client.ping()
    except Exception as e:
        logger.critical(f"Redis health check FAILED: {e}")
        _alert_admin(f"Redis health check failed: {e}")
        failures += 1

    return 1, failures


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_recent_gap(user) -> str:
    try:
        from models import IbGap
        gap = IbGap.query.filter_by(user_id=user.id, is_dismissed=False)\
            .order_by(IbGap.last_seen_at.desc()).first()
        return gap.gap_text if gap else None
    except Exception:
        return None


def _get_last_topic(user) -> str:
    try:
        from models import Session
        s = Session.query.filter_by(user_id=user.id)\
            .order_by(Session.started_at.desc()).first()
        return s.topic if s else None
    except Exception:
        return None


def _alert_admin(message: str):
    """Send critical alert email to admin."""
    try:
        import os, resend
        resend.api_key = os.environ.get("RESEND_API_KEY", "")
        if resend.api_key:
            resend.Emails.send({
                "from": "alerts@mirra.app",
                "to": os.environ.get("ADMIN_EMAIL", ""),
                "subject": f"[MIRRA ALERT] {message[:80]}",
                "text": message,
            })
    except Exception as e:
        logger.error(f"Admin alert delivery failed: {e}")
