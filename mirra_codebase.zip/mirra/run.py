"""run.py — Application entry point."""
import os
from app import create_app

config = os.environ.get("FLASK_ENV", "development")
app = create_app(config)

if __name__ == "__main__":
    app.run(debug=(config == "development"), host="0.0.0.0", port=5000)
