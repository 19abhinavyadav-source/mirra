"""
config.py — Environment-specific settings for Mirra.
"""

import os
from datetime import timedelta


class BaseConfig:
    # ── Core ─────────────────────────────────────────────────────────────────
    SECRET_KEY = os.environ.get("SECRET_KEY") or "CHANGE_ME_IN_PRODUCTION"
    DEBUG = False
    TESTING = False

    # ── Database ─────────────────────────────────────────────────────────────
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "postgresql://mirra:mirra@localhost:5432/mirra_dev"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_size": 10,
        "pool_recycle": 300,
        "pool_pre_ping": True,
        "max_overflow": 20,
    }

    # ── Redis ─────────────────────────────────────────────────────────────────
    REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")

    # ── JWT ───────────────────────────────────────────────────────────────────
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)

    # ── Anthropic ─────────────────────────────────────────────────────────────
    ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
    CLAUDE_SONNET_MODEL = "claude-sonnet-4-5"
    CLAUDE_HAIKU_MODEL = "claude-haiku-4-5-20251001"

    # ── Twilio ────────────────────────────────────────────────────────────────
    TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
    TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "")
    TWILIO_VERIFY_SID = os.environ.get("TWILIO_VERIFY_SID", "")

    # ── Razorpay ──────────────────────────────────────────────────────────────
    RAZORPAY_KEY_ID = os.environ.get("RAZORPAY_KEY_ID", "")
    RAZORPAY_KEY_SECRET = os.environ.get("RAZORPAY_KEY_SECRET", "")

    # ── Resend (email alerts) ─────────────────────────────────────────────────
    RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@mirra.app")

    # ── Cost limits ───────────────────────────────────────────────────────────
    DAILY_SPEND_ALERT_PAISE = int(os.environ.get("DAILY_SPEND_ALERT_PAISE", 200000))  # ₹2,000
    PER_USER_DAILY_COST_MULTIPLIER = 5  # pause user if they hit 5× expected cost

    # ── OTP ───────────────────────────────────────────────────────────────────
    OTP_MAX_SENDS_PER_HOUR = 3
    OTP_MAX_FAILS_BEFORE_LOCKOUT = 5
    OTP_EXPIRY_SECONDS = 600  # 10 minutes

    # ── Subscription plans (question limits) ─────────────────────────────────
    PLAN_LIMITS = {
        "trial": 20,
        "basic": 150,
        "pro": 350,
        "elite": 800,
    }
    PLAN_PRICES_PAISE = {
        "basic": 50000,   # ₹500
        "pro": 100000,    # ₹1,000
        "elite": 200000,  # ₹2,000
    }

    # ── Scheduler ─────────────────────────────────────────────────────────────
    SCHEDULER_TIMEZONE = "Asia/Kolkata"


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    OTP_TEST_MODE = True  # 000000 always works


class ProductionConfig(BaseConfig):
    OTP_TEST_MODE = False

    @classmethod
    def init_app(cls, app):
        import logging
        from logging.handlers import RotatingFileHandler
        file_handler = RotatingFileHandler("logs/mirra.log", maxBytes=10 * 1024 * 1024, backupCount=10)
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        app.logger.setLevel(logging.INFO)


class TestingConfig(BaseConfig):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    OTP_TEST_MODE = True
    WTF_CSRF_ENABLED = False


def get_config(name: str = "development"):
    configs = {
        "development": DevelopmentConfig,
        "production": ProductionConfig,
        "testing": TestingConfig,
    }
    return configs.get(name, DevelopmentConfig)
