"""
Mirra — AI Socratic Tutor
Application factory: creates and configures the Flask app.
"""

from flask import Flask
from extensions import db, migrate, login_manager, redis_client
from config import get_config


def create_app(config_name: str = "development") -> Flask:
    app = Flask(__name__)
    app.config.from_object(get_config(config_name))

    # ── Extensions ──────────────────────────────────────────────────────────
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    # ── Security headers (after every response) ──────────────────────────────
    @app.after_request
    def set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Strict-Transport-Security"] = (
            "max-age=31536000; includeSubDomains"
        )
        return response

    # ── Blueprints ───────────────────────────────────────────────────────────
    from blueprints.auth import auth_bp
    from blueprints.onboarding import onboarding_bp
    from blueprints.session import session_bp
    from blueprints.dashboard import dashboard_bp
    from blueprints.payments import payments_bp
    from blueprints.admin import admin_bp
    from blueprints.health import health_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(onboarding_bp, url_prefix="/onboarding")
    app.register_blueprint(session_bp, url_prefix="/session")
    app.register_blueprint(dashboard_bp, url_prefix="/dashboard")
    app.register_blueprint(payments_bp, url_prefix="/payments")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(health_bp)

    # ── Background jobs ───────────────────────────────────────────────────────
    from services.scheduler import start_scheduler
    start_scheduler(app)

    return app
