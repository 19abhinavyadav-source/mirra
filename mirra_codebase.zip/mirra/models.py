"""
models.py — All SQLAlchemy models for Mirra.

Tables:
  users             core user record
  otp_attempts      OTP rate-limiting / lockout tracking
  sessions          a tutoring session (one topic, one sitting)
  exchanges         individual Q&A pairs inside a session
  ib_gaps           detected reasoning patterns per student
  subscriptions     current subscription state (one active per user)
  payments          every payment attempt (Razorpay)
  check_ins         daily morning message log
  weekly_reports    Sunday AI-generated reasoning report
  analytics_events  generic event stream for product analytics
  api_calls         every Claude API call with cost tracking
  push_subscriptions  Web Push endpoint per user/device
  jobs_log          background job execution history
"""

import uuid
from datetime import datetime, timezone

from extensions import db


def _uuid():
    return str(uuid.uuid4())


def _now():
    return datetime.now(timezone.utc)


# ── Enums (stored as VARCHAR with CHECK constraints) ────────────────────────
PROGRAMMES = ("IB_DP", "IB_MYP", "IGCSE", "A_LEVELS")
ASSESSMENTS = ("TOK_ESSAY", "EXTENDED_ESSAY", "IA", "EXAM_PREP")
PLANS = ("trial", "basic", "pro", "elite")
PROGRESS_STATES = ("DEEPENING", "SURFACE", "STUCK", "BREAKTHROUGH", "CIRCULAR")
QUERY_TYPES = (
    "concept_explanation", "essay_help", "argument_validation",
    "exam_prep", "ib_assessment", "general_question", "emotional"
)
QUESTION_TYPES = ("TYPE_A", "TYPE_B", "TYPE_C", "TYPE_D", "TYPE_E", "TYPE_F", "TYPE_G")
INPUT_TYPES = ("text", "voice", "image", "combined")


# ── Users ────────────────────────────────────────────────────────────────────
class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    phone_number = db.Column(db.String(15), unique=True, nullable=False)  # +91XXXXXXXXXX
    name = db.Column(db.String(100))
    programme = db.Column(db.String(20), db.CheckConstraint(f"programme IN {PROGRAMMES}"))
    subjects = db.Column(db.ARRAY(db.Text))
    active_assessment = db.Column(db.String(20), db.CheckConstraint(f"active_assessment IN {ASSESSMENTS}"))
    assessment_deadline = db.Column(db.DateTime(timezone=True))

    # Plan / billing
    plan = db.Column(db.String(10), default="trial", nullable=False,
                     server_default="trial")
    trial_started_at = db.Column(db.DateTime(timezone=True), default=_now)
    trial_questions_used = db.Column(db.Integer, default=0, nullable=False)
    monthly_questions_used = db.Column(db.Integer, default=0, nullable=False)
    question_limit = db.Column(db.Integer, default=20, nullable=False)
    questions_reset_at = db.Column(db.DateTime(timezone=True))
    paid_until = db.Column(db.DateTime(timezone=True))

    # Engagement
    session_count = db.Column(db.Integer, default=0, nullable=False)
    streak_days = db.Column(db.Integer, default=0)
    last_active_at = db.Column(db.DateTime(timezone=True))

    # State
    is_onboarded = db.Column(db.Boolean, default=False, nullable=False)
    trial_nudge_sent = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)

    created_at = db.Column(db.DateTime(timezone=True), default=_now, nullable=False)
    updated_at = db.Column(db.DateTime(timezone=True), default=_now, onupdate=_now)

    # Relationships
    sessions = db.relationship("Session", backref="user", lazy="dynamic", cascade="all, delete-orphan")
    gaps = db.relationship("IbGap", backref="user", lazy="dynamic", cascade="all, delete-orphan")
    subscriptions = db.relationship("Subscription", backref="user", lazy="dynamic", cascade="all, delete-orphan")
    payments = db.relationship("Payment", backref="user", lazy="dynamic", cascade="all, delete-orphan")

    # Flask-Login interface
    @property
    def is_authenticated(self):
        return True

    @property
    def is_anonymous(self):
        return False

    def get_id(self):
        return self.id

    def can_ask(self) -> bool:
        """True if user still has questions available."""
        from datetime import timezone
        now = datetime.now(timezone.utc)
        # Trial check
        if self.plan == "trial":
            trial_limit = 20
            if self.monthly_questions_used >= trial_limit:
                return False
            # 7-day trial window
            if self.trial_started_at:
                delta = now - self.trial_started_at.replace(tzinfo=timezone.utc) if self.trial_started_at.tzinfo is None else now - self.trial_started_at
                if delta.days >= 7:
                    return False
            return True
        # Paid check
        if self.paid_until:
            paid_until = self.paid_until.replace(tzinfo=timezone.utc) if self.paid_until.tzinfo is None else self.paid_until
            if paid_until < now:
                return False
        return self.monthly_questions_used < self.question_limit

    def questions_remaining(self) -> int:
        return max(0, self.question_limit - self.monthly_questions_used)

    def decrement_question(self) -> None:
        self.monthly_questions_used += 1
        if self.plan == "trial":
            self.trial_questions_used += 1

    def __repr__(self):
        return f"<User {self.phone_number} plan={self.plan}>"


# ── OTP Attempts ─────────────────────────────────────────────────────────────
class OtpAttempt(db.Model):
    __tablename__ = "otp_attempts"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    phone_number = db.Column(db.String(15), nullable=False, index=True)
    sends_this_hour = db.Column(db.Integer, default=0)
    fails_this_hour = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime(timezone=True))
    window_start = db.Column(db.DateTime(timezone=True), default=_now)
    created_at = db.Column(db.DateTime(timezone=True), default=_now)
    updated_at = db.Column(db.DateTime(timezone=True), default=_now, onupdate=_now)


# ── Sessions ─────────────────────────────────────────────────────────────────
class Session(db.Model):
    __tablename__ = "sessions"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    topic = db.Column(db.Text, nullable=False)
    assessment_context = db.Column(db.String(20))
    subject = db.Column(db.String(100))
    exchange_count = db.Column(db.Integer, default=0, nullable=False)
    final_state = db.Column(db.String(20))
    breakthrough_achieved = db.Column(db.Boolean, default=False)
    total_tokens_used = db.Column(db.Integer, default=0)
    total_cost_paise = db.Column(db.Integer, default=0)
    started_at = db.Column(db.DateTime(timezone=True), default=_now, nullable=False)
    ended_at = db.Column(db.DateTime(timezone=True))

    exchanges = db.relationship("Exchange", backref="session", lazy="dynamic", cascade="all, delete-orphan", order_by="Exchange.exchange_number")
    gaps = db.relationship("IbGap", backref="session", lazy="dynamic", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "topic": self.topic,
            "subject": self.subject,
            "exchange_count": self.exchange_count,
            "breakthrough_achieved": self.breakthrough_achieved,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "ended_at": self.ended_at.isoformat() if self.ended_at else None,
        }


# ── Exchanges ────────────────────────────────────────────────────────────────
class Exchange(db.Model):
    __tablename__ = "exchanges"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    session_id = db.Column(db.String(36), db.ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    exchange_number = db.Column(db.Integer, nullable=False)

    student_input = db.Column(db.Text, nullable=False)
    mirra_response = db.Column(db.Text, nullable=False)

    input_type = db.Column(db.String(20), default="text")
    query_type = db.Column(db.String(40))
    progress_state = db.Column(db.String(20))
    question_type_used = db.Column(db.String(10))

    tokens_input = db.Column(db.Integer)
    tokens_output = db.Column(db.Integer)
    model_used = db.Column(db.String(50))
    response_time_ms = db.Column(db.Integer)
    cost_paise = db.Column(db.Integer, default=0)
    has_image = db.Column(db.Boolean, default=False)
    gap_detected = db.Column(db.Boolean, default=False)

    created_at = db.Column(db.DateTime(timezone=True), default=_now, nullable=False)

    __table_args__ = (
        db.UniqueConstraint("session_id", "exchange_number", name="uq_session_exchange"),
    )


# ── IB Gaps (Mistake DNA) ────────────────────────────────────────────────────
class IbGap(db.Model):
    __tablename__ = "ib_gaps"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    session_id = db.Column(db.String(36), db.ForeignKey("sessions.id", ondelete="CASCADE"), index=True)
    exchange_number = db.Column(db.Integer)

    gap_text = db.Column(db.Text, nullable=False)
    gap_category = db.Column(db.String(50))
    confidence = db.Column(db.String(10))
    evidence_quote = db.Column(db.Text)
    subject = db.Column(db.String(100))
    assessment_type = db.Column(db.String(20))

    occurrence_count = db.Column(db.Integer, default=1, nullable=False)
    is_dismissed = db.Column(db.Boolean, default=False, nullable=False)

    first_seen_at = db.Column(db.DateTime(timezone=True), default=_now)
    last_seen_at = db.Column(db.DateTime(timezone=True), default=_now)

    def to_dict(self):
        return {
            "id": self.id,
            "gap_text": self.gap_text,
            "gap_category": self.gap_category,
            "occurrence_count": self.occurrence_count,
            "is_dismissed": self.is_dismissed,
            "subject": self.subject,
            "last_seen_at": self.last_seen_at.isoformat() if self.last_seen_at else None,
        }


# ── Subscriptions ─────────────────────────────────────────────────────────────
class Subscription(db.Model):
    __tablename__ = "subscriptions"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    plan = db.Column(db.String(10), nullable=False)
    status = db.Column(db.String(20), default="active")  # active, cancelled, expired
    started_at = db.Column(db.DateTime(timezone=True), default=_now, nullable=False)
    expires_at = db.Column(db.DateTime(timezone=True))
    question_limit = db.Column(db.Integer, nullable=False)
    price_paise = db.Column(db.Integer)
    razorpay_payment_id = db.Column(db.String(100))
    created_at = db.Column(db.DateTime(timezone=True), default=_now)


# ── Payments ──────────────────────────────────────────────────────────────────
class Payment(db.Model):
    __tablename__ = "payments"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    razorpay_order_id = db.Column(db.String(100), unique=True, nullable=False)
    razorpay_payment_id = db.Column(db.String(100), unique=True)
    razorpay_signature = db.Column(db.String(256))
    amount_paise = db.Column(db.Integer, nullable=False)
    plan = db.Column(db.String(10), nullable=False)
    status = db.Column(db.String(20), default="pending")  # pending, success, failed
    webhook_received_at = db.Column(db.DateTime(timezone=True))
    created_at = db.Column(db.DateTime(timezone=True), default=_now, nullable=False)
    updated_at = db.Column(db.DateTime(timezone=True), default=_now, onupdate=_now)


# ── Check-ins ─────────────────────────────────────────────────────────────────
class CheckIn(db.Model):
    __tablename__ = "check_ins"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    message = db.Column(db.Text)
    sent_at = db.Column(db.DateTime(timezone=True), default=_now)
    delivery_method = db.Column(db.String(20))  # push, whatsapp, skip
    opened = db.Column(db.Boolean, default=False)


# ── Weekly Reports ────────────────────────────────────────────────────────────
class WeeklyReport(db.Model):
    __tablename__ = "weekly_reports"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    week_start = db.Column(db.Date, nullable=False)
    sessions_count = db.Column(db.Integer)
    breakthroughs_count = db.Column(db.Integer)
    top_gap_summary = db.Column(db.Text)
    report_text = db.Column(db.Text)
    tokens_used = db.Column(db.Integer)
    generated_at = db.Column(db.DateTime(timezone=True), default=_now)
    read_at = db.Column(db.DateTime(timezone=True))


# ── Analytics Events ──────────────────────────────────────────────────────────
class AnalyticsEvent(db.Model):
    __tablename__ = "analytics_events"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="SET NULL"), index=True)
    event_name = db.Column(db.String(100), nullable=False, index=True)
    properties = db.Column(db.JSON)
    session_id = db.Column(db.String(36))
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.Text)
    created_at = db.Column(db.DateTime(timezone=True), default=_now, index=True)


# ── API Calls (cost tracking) ────────────────────────────────────────────────
class ApiCall(db.Model):
    __tablename__ = "api_calls"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="SET NULL"), index=True)
    task = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(60), nullable=False)
    prompt_version = db.Column(db.String(20))
    tokens_input = db.Column(db.Integer)
    tokens_output = db.Column(db.Integer)
    cost_paise = db.Column(db.Integer)
    latency_ms = db.Column(db.Integer)
    success = db.Column(db.Boolean, default=True)
    error_code = db.Column(db.String(50))
    created_at = db.Column(db.DateTime(timezone=True), default=_now, index=True)


# ── Push Subscriptions ────────────────────────────────────────────────────────
class PushSubscription(db.Model):
    __tablename__ = "push_subscriptions"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    endpoint = db.Column(db.Text, nullable=False)
    p256dh_key = db.Column(db.Text)
    auth_key = db.Column(db.Text)
    created_at = db.Column(db.DateTime(timezone=True), default=_now)


# ── Background Jobs Log ───────────────────────────────────────────────────────
class JobsLog(db.Model):
    __tablename__ = "jobs_log"

    id = db.Column(db.String(36), primary_key=True, default=_uuid)
    job_name = db.Column(db.String(100), nullable=False)
    started_at = db.Column(db.DateTime(timezone=True), nullable=False)
    completed_at = db.Column(db.DateTime(timezone=True))
    users_processed = db.Column(db.Integer, default=0)
    failures = db.Column(db.Integer, default=0)
    notes = db.Column(db.Text)
    success = db.Column(db.Boolean)
